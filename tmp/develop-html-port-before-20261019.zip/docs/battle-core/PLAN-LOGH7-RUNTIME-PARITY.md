# HTML 함대 기동의 develop 통합

2026-10-17. 원본 origin/feature/fleet-motion-logh7-poc ad75ba0의 docs/poc/fleet-motion-ref/index.html. 기반 develop 1e567f6. 구현 브랜치 codex/logh7-runtime-parity-local.

## 사용자 확정 범위

- develop 실제 전투 화면에 조작·기동·표시 전체를 반영한다.
- 적벽 편성·전투 수치 및 탐지 정보 경계는 기존 정본을 유지한다. 6대6/각100척, 시야250/450, 피해/사거리/AI 임시 수치를 가져오지 않는다.
- 그룹은 여러 함대를 선택·지휘하는 메타데이터다. 적벽 편제·장수·함종·진형 보너스를 바꾸지 않는다.
- 기존 공유 main 및 다른 세션 미커밋 자료와 develop worktree import 변경을 보존한다. main 통합하지 않는다.

## 완료 체크리스트

- [ ] 단일/더블/수정키/상자/전체 선택과 중첩 묶음 선택 정리
- [ ] 묶기·중첩·해제·개별명령 이탈·자식1개 자동해제·죽은 구성원 정리
- [ ] 우클릭 이동·우드래그 목적지/도착방향·상황메뉴·키보드·터치/롱프레스
- [ ] 묶음 상대배치 회전/평행이동·동시도착·묶음 진형의 재귀 재배치
- [ ] 5가지 화면 진형·진형 전환 보간·고정슬롯/격침구멍
- [ ] 제자리 반전·접적 평행이동·개별함선 조준·방향 유지 후퇴
- [ ] 도착 미리보기·이동늘림·윤곽·기존 정본 시야/정찰 표시
- [ ] 이름/진형/상태·그룹 표시·명령 완료 로그·옵션/도움말·재시작
- [ ] 코어/입력/화면 회귀 및 원본 selfTest 항목 대조(적벽 통합 차이 명시)
- [ ] import·일반 게이트 단독순차·기존 boundary와 신규 실패 분리
- [ ] PC 두 해상도 실제 장면 캡처·입력 경로·4시드 전후 대조
- [ ] 구현과 다른 모델의 독립5-b·발견사항 수정
- [ ] develop 반영·푸시·인계/체크리스트 업데이트

## 책임과 검증

조율 root. 코어 runtime_impl(gpt-6.1-sol), 입력/HUD poc_parity_audit(gpt-6.1-sol), 화면 runtime_visual(gpt-6.1-sol). 5-b는 별도 gpt-6-astra로 수행한다. 코드K6/문서K3. 테스트는 Godot4.7.2 단독순차, salvo_compare --runs10. capture/audit/bench는 일반 게이트에서 구분한다. Android/태블릿은 이번 PC 작업의 미검증 범위로 기록한다.

## 투영 계약

move args.fleet_targets={id:Vector2}, sync_arrival=true. 아군 투영 layout_heading, slot_sign, flip_hold_s, aim_heading, motion_contact, motion_speed. 형상/함선조준과 기존 전투 heading을 분리하여 기존 사격각·방향피해 수치를 보존한다. 그룹트리·옵션은 입력/호스트 소유, 렌더는 읽기만 한다.

