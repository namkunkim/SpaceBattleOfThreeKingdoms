class_name FleetMotionGroups
extends RefCounted

# 지휘 묶음은 선택 메타데이터이며 적벽 편제·정본 수치를 바꾸지 않는다.
var host: Node
var nodes := {}
var parents := {}
var chosen: Array = []
var published: Array = []
var next_id := -1000
var destination_facings := {}

func _init(b: Node) -> void:
	host = b

func reset() -> void:
	nodes.clear()
	parents.clear()
	chosen.clear()
	published.clear()
	next_id = -1000

func leaves(id: int) -> Array:
	if not nodes.has(id):
		var f = host.by_id(id)
		return [id] if f != null and not f.dead and f.side == 0 else []
	var out := []
	for child in nodes[id].children:
		out.append_array(leaves(child))
	return out

func top(id: int) -> int:
	while parents.has(id):
		id = parents[id]
	return id

func norm(ids: Array) -> Array:
	var out := []
	for id in ids:
		if out.has(id) or leaves(id).is_empty():
			continue
		var p: int = id
		var covered := false
		while parents.has(p):
			p = parents[p]
			covered = covered or ids.has(p)
		if not covered:
			out.append(id)
	return out

func selection() -> Array:
	var flat := []
	for f in host.selected:
		if f != null and not f.dead and f.side == 0:
			flat.append(f.id)
	var a := flat.duplicate()
	var b := published.duplicate()
	a.sort()
	b.sort()
	if a != b:
		chosen = norm(flat)
	chosen = norm(chosen)
	return chosen.duplicate()

func select_nodes(ids: Array, toggle := false) -> void:
	var out: Array = selection() if toggle else []
	for id in ids:
		if toggle and out.has(id):
			out.erase(id)
		else:
			out.append(id)
	chosen = norm(out)
	publish()

func publish() -> void:
	published = []
	for id in chosen:
		published.append_array(leaves(id))
	host.selected.clear()
	for id in published:
		var f = host.by_id(id)
		if f != null:
			host.selected.append(f)
	host.inspect = null
	host.refresh_panel()

func center(id: int) -> Vector2:
	var ids := leaves(id)
	var p := Vector2.ZERO
	for fid in ids:
		p += host.by_id(fid).pos
	return p / maxf(1.0, ids.size())

func heading(ids: Array) -> float:
	var dir := Vector2.ZERO
	for id in ids:
		for fid in leaves(id):
			var f = host.by_id(fid)
			var h = f.get("layout_heading")
			dir += Vector2.from_angle(float(h) if h != null else f.heading)
	return dir.angle()

func capture(id: int) -> void:
	var g: Dictionary = nodes[id]
	var c := Vector2.ZERO
	for child in g.children:
		c += center(child)
	c /= maxf(1.0, g.children.size())
	g.h = heading(g.children)
	g.offs = []
	for child in g.children:
		g.offs.append((center(child) - c).rotated(-g.h))

func detach(id: int) -> void:
	if not parents.has(id):
		return
	var p: int = parents[id]
	var g: Dictionary = nodes[p]
	var i: int = g.children.find(id)
	g.children.remove_at(i)
	g.offs.remove_at(i)
	parents.erase(id)
	if g.children.size() < 2:
		dissolve(p)

func dissolve(id: int) -> void:
	if not nodes.has(id):
		return
	var children: Array = nodes[id].children.duplicate()
	var p: int = parents.get(id, 0)
	if parents.has(id):
		var at: int = nodes[p].children.find(id)
		nodes[p].children.remove_at(at)
		for child in children:
			nodes[p].children.insert(at, child)
			parents[child] = p
			at += 1
	else:
		for child in children:
			parents.erase(child)
	parents.erase(id)
	nodes.erase(id)
	if p != 0 and nodes.has(p):
		capture(p)
	if chosen.has(id):
		chosen.erase(id)
		chosen.append_array(children)

func node_name(id: int) -> String:
	if nodes.has(id):
		return nodes[id].name
	var f = host.by_id(id)
	return str(f.fname) if f else "함대"

func group_selection() -> void:
	var ids := selection()
	if ids.size() < 2:
		host.toast("묶으려면 2개 이상 선택하세요")
		return
	var title := []
	for id in ids:
		title.append(node_name(id))
		detach(id)
	var gid := next_id
	next_id -= 1
	nodes[gid] = {"name": " + ".join(title), "children": ids.duplicate(), "offs": [], "h": 0.0, "form": ""}
	for id in ids:
		parents[id] = gid
	capture(gid)
	select_nodes([gid])
	host.toast("%s: 하나의 묶음으로 지휘" % nodes[gid].name)

func ungroup_selection() -> void:
	var out := []
	for id in selection():
		if nodes.has(id):
			out.append_array(nodes[id].children)
			host.toast("%s: 묶음 해제" % node_name(id))
			dissolve(id)
		else:
			out.append(id)
	select_nodes(out)

func prepare_order() -> void:
	var ids := selection()
	for id in ids:
		if parents.has(id):
			host.toast("%s: %s에서 이탈(개별 명령)" % [node_name(id), node_name(parents[id])])
			detach(id)
	chosen = norm(ids)
	publish()

func box_nodes(a: Vector2, b: Vector2) -> Array:
	var rect := Rect2(a, Vector2.ZERO).expand(b)
	var inside := []
	for f in host.alive(0):
		if rect.has_point(host.w2s(f.pos)):
			inside.append(f.id)
	var out := []
	for fid in inside:
		var id: int = fid
		while parents.has(id):
			var p: int = parents[id]
			if not leaves(p).all(func(x): return inside.has(x)):
				break
			id = p
		out.append(id)
	return norm(out)

func in_contact(id: int) -> bool:
	for fid in leaves(id):
		if host.by_id(fid).get("motion_contact") == true:
			return true
	return false

func plan(id: int, point: Vector2, face, out: Dictionary) -> void:
	if not nodes.has(id):
		out[id] = point
		if face != null:
			destination_facings[id] = float(face)
		return
	var g: Dictionary = nodes[id]
	var delta := point - center(id)
	var h: float = g.h if in_contact(id) else (float(face) if face != null else (delta.angle() if delta.length() > 5.0 else float(g.h)))
	if host.logh7_options.flip and absf(angle_difference(g.h, h)) > PI * 0.5:
		g.offs = g.offs.map(func(v): return -v)
	g.h = h
	for i in g.children.size():
		plan(g.children[i], point + (g.offs[i] as Vector2).rotated(h), h, out)

func move_targets(point: Vector2, face = null) -> Dictionary:
	destination_facings.clear()
	prepare_order()
	var ids := selection()
	var out := {}
	if ids.size() == 1:
		plan(ids[0], point, face, out)
	elif not ids.is_empty():
		var c := Vector2.ZERO
		for id in ids:
			c += center(id)
		c /= ids.size()
		var h := heading(ids)
		var goal: float = h if ids.any(in_contact) else (float(face) if face != null else (point - c).angle())
		var reverse: bool = host.logh7_options.flip and absf(angle_difference(h, goal)) > PI * 0.5
		for id in ids:
			var off := (center(id) - c).rotated(-h)
			plan(id, point + (-off if reverse else off).rotated(goal), goal, out)
	return out

func overlay_groups() -> Array:
	selection()
	var out := []
	for id in nodes:
		var ids := leaves(id)
		if ids.is_empty():
			continue
		var on := chosen.has(id)
		var p: int = id
		while parents.has(p):
			p = parents[p]
			on = on or chosen.has(p)
		out.append({"id": id, "name": nodes[id].name, "fleet_ids": ids, "selected": on})
	return out

func prune() -> void:
	for id in nodes.keys():
		if not nodes.has(id):
			continue
		for child in nodes[id].children.duplicate():
			if leaves(child).is_empty():
				detach(child)
	chosen = norm(chosen)

static func shape(key: String, i: int, n: int) -> Vector2:
	var mid := (n - 1) * 0.5
	match key:
		"line": return Vector2(0, i - mid)
		"column": return Vector2(mid - i, 0)
		"echelon": return Vector2((mid - i) * 0.7, i - mid)
		"arc":
			var a := deg_to_rad(-60.0 + 120.0 * i / maxf(1.0, n - 1))
			return Vector2(1.0 - cos(a), sin(a)) * (n - 1) * 0.6
	var cols := ceili(sqrt(n))
	return Vector2(-floori(float(i) / cols), i % cols - (mini(n, cols) - 1) * 0.5)

func extent(id: int, key: String) -> Vector2:
	if nodes.has(id):
		var ext := Vector2.ZERO
		for i in nodes[id].children.size():
			ext = ext.max((nodes[id].offs[i] as Vector2).abs() + extent(nodes[id].children[i], key))
		return ext
	var renderer = host.presentation.renderer if host.presentation else null
	if renderer and renderer.vis.has(id):
		var ext := Vector2.ZERO
		# 현재 렌더 크기를 보수적으로 사용한다. 시각 담당의 목표형 헬퍼가 있으면 목표형을 사용.
		if renderer.has_method("motion_half_extent"):
			return renderer.motion_half_extent(id, key)
		for slot in renderer.vis[id].slots:
			ext = ext.max(Vector2(slot.home.z, slot.home.x).abs())
		return ext
	return Vector2(75, 75)

func group_form(id: int, key: String) -> void:
	if not nodes.has(id):
		return
	var g: Dictionary = nodes[id]
	g.form = key
	for child in g.children:
		group_form(child, key)
	var ext := Vector2.ZERO
	for child in g.children:
		ext = ext.max(extent(child, key))
	var spacing := ext * 2.0 + Vector2(30, 30)
	var slots := []
	var mean := Vector2.ZERO
	for i in g.children.size():
		var p := shape(key, i, g.children.size()) * spacing
		slots.append(p)
		mean += p
	mean /= slots.size()
	for i in slots.size():
		slots[i] -= mean
	var c := center(id)
	var lateral: bool = not slots.all(func(v): return is_equal_approx(v.y, slots[0].y))
	var children: Array = g.children.duplicate()
	children.sort_custom(func(a, b):
		var pa := (center(a) - c).rotated(-g.h)
		var pb := (center(b) - c).rotated(-g.h)
		return pa.y * 10000.0 - pa.x < pb.y * 10000.0 - pb.x if lateral else pa.x > pb.x)
	slots.sort_custom(func(a, b): return a.y * 10000.0 - a.x < b.y * 10000.0 - b.x if lateral else a.x > b.x)
	g.offs = []
	for child in g.children:
		g.offs.append(slots[children.find(child)])

func form_targets(key: String) -> Dictionary:
	destination_facings.clear()
	var out := {}
	for id in selection():
		if nodes.has(id):
			group_form(id, key)
			plan(id, center(id), nodes[id].h, out)
	return out
