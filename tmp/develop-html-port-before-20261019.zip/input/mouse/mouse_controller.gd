class_name MouseController
extends Node

const MI := -2
const MOVE := 8.0
var battle: Node
var touch: TouchController
var _right := false
var _dragging := false
var _start := Vector2.ZERO
var _ally = null

func setup(b: Node, t: TouchController) -> void:
	battle = b
	touch = t

func _unhandled_input(e: InputEvent) -> void:
	if battle == null or battle.G.state != "play" or e.device == InputEvent.DEVICE_ID_EMULATION:
		return
	if e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_RIGHT:
		battle.motion_panel.hide_menu()
		_right = true
		_dragging = false
		_start = e.position
		var f = battle._hit_fleet(e.position)
		_ally = f if f != null and f.side == 0 else null
		get_viewport().set_input_as_handled()

func _input(e: InputEvent) -> void:
	if not _right or e.device == InputEvent.DEVICE_ID_EMULATION:
		return
	if battle.G.state != "play":
		_right = false
		touch.order = {}
		return
	if e is InputEventMouseMotion:
		_motion(e.position)
		get_viewport().set_input_as_handled()
	elif e is InputEventMouseButton and not e.pressed and e.button_index == MOUSE_BUTTON_RIGHT:
		_release(e.position)
		get_viewport().set_input_as_handled()

func _motion(p: Vector2) -> void:
	if not _dragging and p.distance_to(_start) <= MOVE:
		return
	_dragging = true
	if battle.my_sel().is_empty():
		return
	touch.order = {"from_fleet": battle.my_sel()[0], "to": _start, "target": null, "cancel": false, "slide": false, "motion_face": (battle.s2w(p) - battle.s2w(_start)).angle()}
	touch.order_preview_changed.emit()

func _release(p: Vector2) -> void:
	_right = false
	touch.order = {}
	touch.order_preview_changed.emit()
	if not _dragging and _ally != null:
		battle.motion_panel.show_menu(_ally, p)
	elif not battle.my_sel().is_empty():
		var face = rad_to_deg((battle.s2w(p) - battle.s2w(_start)).angle()) if _dragging else null
		battle.order_move(battle.s2w(_start), false, face)
	_dragging = false
	_ally = null
