class_name TouchController
extends Node

# 터치 조작(제안서 v0.2 §7.2). 마우스 조작은 POC 입력 처리를 그대로 쓴다.
#  - 탭: 선택(아군) / 선택이 있으면 적 탭 = 공격, 없으면 정보 / 선택이 있을 때 빈 곳 탭 = 선택 해제
#  - 선택이 있을 때 끌기(아군 전대 또는 빈 곳에서 시작): 선택 전체 이동. 적 위에 놓으면 공격, 시작 지점으로 되돌리면 취소
#  - 선택이 없을 때 빈 곳 끌기: 범위 선택 상자(화면 이동은 두 손가락)
#  - 다중 모드 `battle.multi`: 끌기 = 범위 선택(기존 선택에 더함), 아군 탭 = 추가/해제, 빈 곳 탭은 선택 유지
#  - 길게 누르기(아군): 선택에 추가/제외
#  - 두 손가락: 확대·축소와 화면 이동
#
# Godot는 터치를 마우스(장치 ID = DEVICE_ID_EMULATION)로도 흉내 낸다. HUD 버튼은 그 흉내 이벤트로 눌린다.
# 전장으로 내려온(HUD가 받지 않은) 흉내 마우스 이벤트는 여기서 막아 POC의 마우스 끌기 상자 선택과 겹치지 않게 한다.

signal order_preview_changed

const TAP_MOVE := 14.0
const LONG_PRESS := 0.5
const CANCEL_R := 46.0
const RING_R := 84.0       # 회전 핸들 링 반지름(화면 단위)
const HANDLE_HIT := 40.0   # 핸들 잡기 반경
const RING_BAND := 26.0    # 링 잡기 폭(±)
const DWELL_T := 1.0       # 끌다가 이만큼 멈추면 그 자리가 목적지, 방향 메뉴가 뜬다
const DWELL_MOVE := 14.0
const FACE_HOLD_T := 1.0   # 선택된 함대를 이만큼 누르고 있으면 제자리 방향 메뉴
const MENU_R := 130.0      # 방향 원 반지름
const MENU_BAND := 56.0    # 원 바깥으로 이만큼까지는 방향 조작, 그 밖을 누르면 취소

var battle: Node
var touches := {}          # index -> {start, pos, t0}
var mode := ""             # "", "pending", "ignore", "box", "order", "pinch", "long"
var origin_fleet = null
var press_t := 0.0
var pinch_d := 0.0
var pinch_c := Vector2.ZERO
var turn := {}             # 회전 미리보기: {fleet, rad(월드 각도), cancel}
var order := {}            # 끌기 명령 미리보기: {from: Vector2(px 화면), to, target, cancel}
var _consumed_index := -1

func setup(b: Node) -> void:
	battle = b
	_build_resume()
	Input.emulate_mouse_from_touch = true

# 회전 핸들: 단일 선택 함대의 선두 방향, 링 위. 선택이 1개가 아니면 없다.
func handle_fleet():
	return null

func _legacy_handle_fleet():
	if not battle.G.hold:
		return null   # 일시정지 중에만 회전 핸들·제자리 방향 메뉴
	var s: Array = battle.my_sel()
	return s[0] if (s.size() == 1 and not battle.multi) else null

# 제자리 방향 메뉴를 여는 함대인가: 일시정지 중, 다중 모드가 아니고, 선택된 아군 함대(선택이 몇 개든)
func _face_hold_fleet(f) -> bool:
	if f == null or f.side != 0 or battle.multi or not battle.selected.has(f):
		return false
	return battle.G.hold

# 함대 명령(이동·평행 이동·방향 메뉴·공격)은 일시정지 중에만 낸다. 막히면 안내한다.
var _hint_t := -10.0

func _control_ok() -> bool:
	return true   # PoC 조작은 진행 중에도 명령 가능

func _legacy_control_ok() -> bool:
	if battle.G.hold:
		return true
	var now := Time.get_ticks_msec() / 1000.0
	if now - _hint_t > 2.0:
		_hint_t = now
		battle.toast("일시정지 후 함대를 조작하세요")
	return false

# 이동 방식 토글 알약: 함대 조작 메뉴 안에 둔다(함대 아래, 방향 원 안). 누르면 방향 고정 ↔ 선회.
const PILL := Vector2(210, 48)

func pill_rect(c: Vector2) -> Rect2:
	return Rect2(c - PILL * 0.5, PILL)

func fleet_pill_rect(f) -> Rect2:
	return pill_rect(battle.w2s(f.pos) + Vector2(0, RING_R + 44.0))

func menu_pill_rect() -> Rect2:
	return pill_rect(menu.c + Vector2(0, MENU_R * 0.55))   # 방향 원 아래쪽(함대·화살표를 가리지 않는다)

func pill_text() -> String:
	return "이동: 선회" if turn_move else "이동: 방향 고정"

func handle_pos(f) -> Vector2:
	var c: Vector2 = battle.w2s(f.pos)
	var d: Vector2 = battle.w2s(f.pos + Vector2(cos(f.heading), sin(f.heading)) * 100.0) - c
	return c + (d.normalized() if d.length() > 0.001 else Vector2.RIGHT) * RING_R

# 일시정지/재개 고정 버튼: 이 버튼을 누를 때만 전투 시계가 멈추고(G.hold) 다시 흐른다. 전장 터치는 정지시키지 않는다.
var _resume: Button
var turn_move := false   # false = 방향 고정 이동(평행), true = 선회 이동(진행 방향으로 돌며 이동)
var menu := {}             # 도착 방향 메뉴: {fleet, world(목적지), c(메뉴 중심, 화면), strafe}. 열려 있는 동안 mode == "menu"
var _dwell_t := 0.0
var _dwell_p := Vector2.ZERO

# HUD 버튼·패널의 화면 영역 목록(보이는 STOP 컨트롤 중 화면 40% 미만). 전체 화면을 덮는 컨트롤은 제외한다.
func _hud_rects() -> Array:
	var out := []
	var hud = battle.presentation.hud if battle.presentation else null
	if hud == null:
		return out
	var vs: Vector2 = battle.get_viewport().get_visible_rect().size
	var stack: Array = [hud]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		for ch in n.get_children():
			stack.append(ch)
		if n is Control and n != hud and n.is_visible_in_tree() and n.mouse_filter == Control.MOUSE_FILTER_STOP:
			var r: Rect2 = n.get_global_rect()
			if r.size.x * r.size.y < vs.x * vs.y * 0.4:
				out.append(r)
	return out

# HUD 버튼·패널 위 터치인가(정지를 걸지 않는다)
func _over_hud(p: Vector2) -> bool:
	for r in _hud_rects():
		if r.has_point(p):
			return true
	return false

# 원(중심 c, 반지름 rad)이 사각형과 겹치는가
static func _circle_hits(c: Vector2, rad: float, r: Rect2) -> bool:
	var q := Vector2(clampf(c.x, r.position.x, r.end.x), clampf(c.y, r.position.y, r.end.y))
	return q.distance_to(c) < rad

# 원을 HUD를 피해 놓는다: 원하는 중심에서 가장 가까운 빈 자리(격자 탐색). 빈 자리가 없으면 화면 안으로만 당긴다.
func _free_center(want: Vector2, rad: float) -> Vector2:
	var vs: Vector2 = battle.get_viewport().get_visible_rect().size
	var rects := _hud_rects()
	var best := Vector2(clampf(want.x, rad, vs.x - rad), clampf(want.y, rad, vs.y - rad))
	var best_d := INF
	var found := false
	var y := rad
	while y <= vs.y - rad:
		var x := rad
		while x <= vs.x - rad:
			var c := Vector2(x, y)
			var ok := true
			for r in rects:
				if _circle_hits(c, rad, r):
					ok = false
					break
			if ok:
				var d := c.distance_to(want)
				if d < best_d:
					best_d = d
					best = c
					found = true
			x += 20.0
		y += 20.0
	return best

# 재개 버튼 자리: 좌상단 빈 곳, 눈에 띄는 큰 크기(다른 HUD 배치에 영향 없음)
const RESUME_SIZE := Vector2(300, 110)
var _btn_touch := -1   # 버튼 위에서 시작한 손가락 번호(떼기·끌기까지 소비)

func _place_resume() -> void:
	_resume.size = RESUME_SIZE
	_resume.position = Vector2(16, 16)

func _build_resume() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 8
	add_child(layer)
	_resume = Button.new()
	_resume.text = "⏸ 일시정지"
	_resume.add_theme_font_size_override("font_size", 42)
	_resume.set_anchors_preset(Control.PRESET_TOP_LEFT)
	_resume.visible = false
	_resume.focus_mode = Control.FOCUS_NONE
	_resume.mouse_filter = Control.MOUSE_FILTER_IGNORE   # 입력은 아래 _input이 직접 받는다(다른 손가락이 전장을 누르는 중에도 눌리게)
	layer.add_child(_resume)

# 일시정지/재개 버튼 입력. 터치는 손가락마다, 마우스는 왼쪽 클릭으로 받고 전장·HUD로 넘기지 않는다.
func _input(e: InputEvent) -> void:
	if _resume == null or not _resume.visible:
		return
	var r := Rect2(_resume.position, _resume.size)
	if e is InputEventScreenTouch:
		if e.pressed and r.has_point(e.position):
			_btn_touch = e.index
			battle.G.hold = not battle.G.hold
			UiSound.vibrate(30)
			get_viewport().set_input_as_handled()
		elif not e.pressed and e.index == _btn_touch:
			_btn_touch = -1
			get_viewport().set_input_as_handled()
	elif e is InputEventScreenDrag and e.index == _btn_touch:
		get_viewport().set_input_as_handled()
	elif e is InputEventMouseButton or e is InputEventMouseMotion:
		var emu: bool = e.device == InputEvent.DEVICE_ID_EMULATION
		if emu and r.has_point(e.position):
			get_viewport().set_input_as_handled()   # 터치에서 만든 마우스 흉내는 위에서 이미 처리했다
		elif not emu and e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and e.pressed and r.has_point(e.position):
			battle.G.hold = not battle.G.hold
			get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if _resume:
		# 고정 버튼(자리 A): 플레이 중 "⏸ 일시정지", 정지 중 "▶ 재개". 이동 방식 토글은 정지 중에만 위에 보인다.
		_resume.visible = battle.G.state == "play"
		_resume.text = "▶ 재개" if battle.G.hold else "⏸ 일시정지"
		# 정지 중에는 호박색으로 채워 눈에 띄게 한다
		var hold: bool = battle.G.hold
		var st := UiTheme.flat(Color(UiTheme.GOLD_HI, 0.92) if hold else Color(0.03, 0.05, 0.08, 0.88), UiTheme.GOLD_HI, 3, 12)
		for k in ["normal", "hover", "pressed", "disabled"]:
			_resume.add_theme_stylebox_override(k, st)
		_resume.add_theme_color_override("font_color", Color(0.05, 0.06, 0.08) if hold else UiTheme.GOLD_HI)
		_place_resume()
	if mode == "pending" and touches.size() == 1:
		press_t += dt_real(delta)
		if press_t >= 0.55:
			mode = "long"
			if origin_fleet != null and origin_fleet.side == 0 or not battle.my_sel().is_empty():
				battle.motion_panel.show_menu(origin_fleet if origin_fleet != null and origin_fleet.side == 0 else null, touches.values()[0].start)

func dt_real(delta: float) -> float:
	return UiDraw.real_dt(delta)

func _unhandled_input(e: InputEvent) -> void:
	# 전장에 내려온 터치 흉내 마우스는 POC로 보내지 않는다.
	if (e is InputEventMouseButton or e is InputEventMouseMotion) and e.device == InputEvent.DEVICE_ID_EMULATION:
		get_viewport().set_input_as_handled()
		return
	if battle == null or battle.G.state != "play":
		return
	if e is InputEventScreenTouch:
		_motion_touch(e)
		get_viewport().set_input_as_handled()
	elif e is InputEventScreenDrag:
		_motion_drag(e)
		get_viewport().set_input_as_handled()

func _touch(e: InputEventScreenTouch) -> void:
	if not menu.is_empty():
		if e.pressed:
			_menu_press(e)
		elif menu.get("drag", -1) == e.index:
			menu.drag = -1
			touches.erase(e.index)
			if menu.get("set", false):
				_menu_confirm()   # 방향을 정한 뒤 손을 떼면 자동 확정(확정 버튼 위에서 떼도 확정)
			return
		touches.erase(e.index)
		return
	if e.pressed:
		var pf = handle_fleet()
		if pf and fleet_pill_rect(pf).has_point(e.position):
			turn_move = not turn_move   # 함대 아래 알약으로 이동 방식 전환
			UiSound.vibrate(20)
			return
		touches[e.index] = {"start": e.position, "pos": e.position}
		if touches.size() == 1:
			mode = "pending"
			press_t = 0.0
			origin_fleet = battle._hit_fleet(e.position)
			var hf = handle_fleet()
			if hf and e.position.distance_to(handle_pos(hf)) < HANDLE_HIT:
				mode = "turn"
				origin_fleet = hf
				_update_turn(e.position)
			elif hf and absf(e.position.distance_to(battle.w2s(hf.pos)) - RING_R) < RING_BAND:
				mode = "slide"   # 링 위에서 끌기 = 방향 고정 평행 이동
				origin_fleet = hf
		elif touches.size() == 2:
			_begin_pinch()
		return
	if not touches.has(e.index):
		return
	var tc: Dictionary = touches[e.index]
	touches.erase(e.index)
	if mode == "pinch":
		if touches.is_empty():
			mode = ""
		return
	if mode == "pending":
		battle._click_at(e.position, MOUSE_BUTTON_LEFT, false)
	elif mode == "box":
		battle.input_node.box_select(battle.drag.s, e.position, false)
		battle.drag = {}
	elif mode == "order" or mode == "slide":
		_finish_order(e.position)
	elif mode == "turn":
		_finish_turn(e.position)
	mode = "" if touches.is_empty() else mode
	origin_fleet = null

func _drag(e: InputEventScreenDrag) -> void:
	if not menu.is_empty():
		if menu.drag == e.index and e.position.distance_to(menu.c) > 18.0 and not menu_pill_rect().has_point(e.position):
			menu.a = (e.position - menu.c).angle()   # 확정 버튼 위로 옮기는 동안은 방향을 바꾸지 않는다
			menu.set = true
		return
	if not touches.has(e.index):
		return
	var tc: Dictionary = touches[e.index]
	var last: Vector2 = tc.pos
	tc.pos = e.position
	if mode == "pinch" and touches.size() >= 2:
		_update_pinch()
		return
	if mode == "pending" and (e.position - (tc.start as Vector2)).length() > TAP_MOVE:
		if battle.multi:   # 다중 모드: 어디서 시작하든 끌기 = 범위 선택(명령은 탭으로)
			mode = "box"
			battle.drag = {"s": tc.start, "c": e.position, "btn": -1, "moved": true, "mode": "box", "shift": true, "last": e.position}
		elif not battle.my_sel().is_empty():
			# 선택이 있으면 선택된 전대에서 시작한 끌기만 이동·공격으로 인정, 그 밖에서 시작하면 무시
			mode = "order" if (origin_fleet and origin_fleet.side == 0 and battle.selected.has(origin_fleet) and _control_ok()) else "ignore"
			_dwell_t = 0.0
			_dwell_p = e.position
		elif origin_fleet and origin_fleet.side == 0:   # 선택이 없으면 아군에서 끌기 = 그 전대 선택 + 명령
			if not _control_ok():
				mode = "ignore"
				return
			mode = "order"
			_dwell_t = 0.0
			_dwell_p = e.position
			battle.selected.append(origin_fleet)
			battle.inspect = null
			battle.refresh_panel()
		else:   # 선택이 없으면 끌기 = 범위 선택. 화면 이동은 두 손가락
			mode = "box"
			battle.drag = {"s": tc.start, "c": e.position, "btn": -1, "moved": true, "mode": "box", "shift": false, "last": e.position}
	if mode == "box":
		battle.drag.c = e.position
	elif mode == "turn":
		_update_turn(e.position)
	elif mode == "order" or mode == "slide":
		_update_order(e.position)

# 끌기 명령 미리보기. 전대에서 시작했으면 그 전대, 빈 곳에서 시작했으면 선택의 첫 전대에서 그린다.
# 취소: 시작 지점(전대 또는 처음 짚은 곳) 근처로 되돌려 놓기.
func _update_order(p: Vector2) -> void:
	if origin_fleet == null or battle.my_sel().is_empty():   # 끌기 도중 선택 전대가 모두 사라짐
		order = {}
		return
	if p.distance_to(_dwell_p) > DWELL_MOVE:
		_dwell_p = p
		_dwell_t = 0.0
	# 이동 방식은 turn_move 토글(기본 방향 고정 평행 이동). 적 위에 놓으면 공격
	var tgt = null if mode == "slide" else battle._hit_fleet(p)
	var src = origin_fleet
	var start: Vector2 = battle.w2s(origin_fleet.pos)
	order = {"from_fleet": src, "to": p, "target": tgt if (tgt and tgt.side == 1) else null, "cancel": p.distance_to(start) < CANCEL_R, "slide": not turn_move}
	order_preview_changed.emit()

func _open_menu(face := false) -> void:
	var o := order
	var f = origin_fleet if face else o.from_fleet
	if face:
		o = {"to": battle.w2s(f.pos)}
	var c: Vector2 = _free_center(o.to, MENU_R + 8.0)
	# 화살표 시작 방향 = 함대의 현재 선두 방향(화면 각도)
	var d: Vector2 = battle.w2s(f.pos + Vector2(cos(f.heading), sin(f.heading)) * 100.0) - battle.w2s(f.pos)
	menu = {"fleet": f, "world": battle.s2w(o.to), "to": o.to, "c": c, "face": face, "a": d.angle(), "drag": touches.keys()[0] if touches.size() == 1 else -1}   # 누르고 있는 손가락이 이어서 방향을 정한다
	mode = "menu"
	order = {}
	order_preview_changed.emit()
	UiSound.vibrate(30)

# 화살표(화면 각도)를 월드 각도(도)로
func menu_deg() -> float:
	var dir := Vector2.from_angle(menu.a)
	return rad_to_deg((battle.s2w(menu.to + dir * 100.0) - battle.s2w(menu.to)).angle())

func _menu_confirm() -> void:
	var f = menu.fleet
	var w: Vector2 = menu.world
	var deg := menu_deg()
	var face: bool = menu.face
	menu = {}
	mode = ""
	origin_fleet = null
	order_preview_changed.emit()
	if f and not f.dead and not battle.my_sel().is_empty():
		if face:
			battle.order_face(deg_to_rad(deg))
		else:
			battle.order_move(w, not turn_move, deg)   # 이동하면서(고정 이동) 또는 도착해서(선회 이동) 정한 방향으로 돌아선다

func _menu_press(e: InputEventScreenTouch) -> void:
	var d: float = e.position.distance_to(menu.c)
	if menu_pill_rect().has_point(e.position):
		turn_move = not turn_move   # 방향 원 안 알약으로 이동 방식 전환(원은 열린 채 유지)
		UiSound.vibrate(20)
		return
	if d < MENU_R + MENU_BAND:
		menu.drag = e.index
		menu.a = (e.position - menu.c).angle()
		menu.set = true
	else:   # 바깥 탭: 취소
		print("[TOUCH] menu cancelled by outside tap d=", snappedf(d, 1.0))
		menu = {}
		mode = ""
		origin_fleet = null
		order_preview_changed.emit()

func _update_turn(p: Vector2) -> void:
	var f = origin_fleet
	if f == null or f.dead or battle.my_sel().is_empty():
		turn = {}
		return
	var v: Vector2 = battle.s2w(p) - f.pos
	turn = {"fleet": f, "rad": v.angle(), "cancel": p.distance_to(battle.w2s(f.pos)) < CANCEL_R * 0.6}
	order_preview_changed.emit()

func _finish_turn(_p: Vector2) -> void:
	var t := turn
	turn = {}
	order_preview_changed.emit()
	if not t.is_empty() and not t.cancel:
		battle.order_face(t.rad)

func _finish_order(p: Vector2) -> void:
	var o := order
	order = {}
	order_preview_changed.emit()
	if o.is_empty() or o.cancel:
		print("[TOUCH] order dropped empty=", o.is_empty(), " cancel=", o.get("cancel"))
		return
	if o.target:
		battle.order_attack(o.target)
	else:
		battle.order_move(battle.s2w(p), o.slide)

func _begin_pinch() -> void:
	menu = {}
	mode = "pinch"
	order = {}
	turn = {}
	battle.drag = {}
	origin_fleet = null
	var pts := _two()
	pinch_d = maxf(1.0, pts[0].distance_to(pts[1]))
	pinch_c = (pts[0] + pts[1]) * 0.5

func _update_pinch() -> void:
	var pts := _two()
	var d := maxf(1.0, pts[0].distance_to(pts[1]))
	var c: Vector2 = (pts[0] + pts[1]) * 0.5
	battle._zoom(c, d / pinch_d)
	battle.cam_pos -= (c - pinch_c) / battle.cam_z
	battle._clamp_cam()
	pinch_d = d
	pinch_c = c

func _two() -> Array:
	var out := []
	for k in touches:
		out.append(touches[k].pos)
		if out.size() == 2:
			break
	return out

# PoC 제스처. 두 손가락 카메라는 기존 구현을 재사용한다.
func _motion_touch(e: InputEventScreenTouch) -> void:
	if e.canceled:
		touches.erase(e.index)
		mode = ""
		order = {}
		battle.drag = {}
		origin_fleet = null
		order_preview_changed.emit()
		return
	if e.pressed:
		if _over_hud(e.position) or battle.motion_panel.over_hud(e.position):
			return
		battle.motion_panel.hide_menu()
		touches[e.index] = {"start": e.position, "pos": e.position}
		if touches.size() == 2:
			_begin_pinch()
		elif touches.size() == 1:
			mode = "pending"
			press_t = 0
			origin_fleet = battle._hit_fleet(e.position)
		return
	if not touches.has(e.index):
		return
	var tc: Dictionary = touches[e.index]
	touches.erase(e.index)
	if mode == "pinch":
		if touches.is_empty():
			mode = ""
		return
	if mode == "pending":
		if origin_fleet != null and origin_fleet.side == 0:
			battle.input_node.click_at(e.position, MOUSE_BUTTON_LEFT, false)
		elif not battle.my_sel().is_empty():
			battle.order_move(battle.s2w(tc.start), false)
	elif mode == "box":
		battle.input_node.box_select(tc.start, e.position, false)
	elif mode == "order" and not battle.my_sel().is_empty():
		var face := rad_to_deg((battle.s2w(e.position) - battle.s2w(tc.start)).angle())
		battle.order_move(battle.s2w(tc.start), false, face)
	battle.drag = {}
	order = {}
	order_preview_changed.emit()
	mode = ""
	origin_fleet = null

func _motion_drag(e: InputEventScreenDrag) -> void:
	if not touches.has(e.index):
		return
	var tc: Dictionary = touches[e.index]
	tc.pos = e.position
	if mode == "pinch":
		if touches.size() >= 2:
			_update_pinch()
		return
	if mode == "pending" and e.position.distance_to(tc.start) > 8.0:
		mode = "box" if battle.multi or battle.my_sel().is_empty() or origin_fleet != null and origin_fleet.side == 0 else "order"
	if mode == "box":
		battle.drag = {"s": tc.start, "c": e.position, "btn": -1, "moved": true, "mode": "box", "shift": false, "last": e.position}
	elif mode == "order" and not battle.my_sel().is_empty():
		order = {"from_fleet": battle.my_sel()[0], "to": tc.start, "target": null, "cancel": false, "slide": false, "motion_face": (battle.s2w(e.position) - battle.s2w(tc.start)).angle()}
		order_preview_changed.emit()
