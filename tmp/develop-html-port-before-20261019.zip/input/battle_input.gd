class_name BattleInput
extends Node

# 마우스·키보드 입력: 선택, 그룹, 끌기, 카메라 이동·확대, 명령 단축키. 명령은 BattleCommands를 거친다.
# 선택·그룹·끌기 같은 UI 세션 상태는 호스트(전투 노드)의 필드에 둔다(상품화 HUD가 같은 필드를 읽는다).
# 터치 입력은 input/touch/touch_controller.gd가 맡고, 이 파일의 click_at·hit_fleet·zoom을 호스트를 거쳐 쓴다.

var host: Node
var cmds: BattleCommands
var _last_click := 0
var _last_fleet := -1
var _group_press := {}

func setup(h: Node, c: BattleCommands) -> void:
	host = h
	cmds = c

# 프레임마다: 방향키로 카메라 이동
func poll_camera(dt: float) -> void:
	if host.G.state != "play":
		return
	var ps: float = 700.0 * dt / host.cam_z
	if Input.is_key_pressed(KEY_LEFT):
		host.cam_pos.x -= ps
	if Input.is_key_pressed(KEY_RIGHT):
		host.cam_pos.x += ps
	if Input.is_key_pressed(KEY_UP):
		host.cam_pos.y -= ps
	if Input.is_key_pressed(KEY_DOWN):
		host.cam_pos.y += ps
	host._clamp_cam()

# ---- 히트 테스트 ----
func hit_fleet(sp: Vector2):
	# 공개된 생존 함선 슬롯을 먼저 검사하여 긴 대열의 가장자리도 선택할 수 있게 한다.
	var renderer = host.presentation.renderer if host.presentation else null
	if renderer and renderer.has_method("hit_motion_fleet"):
		var fid: int = renderer.hit_motion_fleet(sp, 10.0)
		if fid >= 0:
			return host.by_id(fid)
	var best = null
	var bd := 1e9
	for f in host.fleets:
		if f.dead:
			continue
		var r: Rect2 = host.label_rect(f)
		if sp.x >= r.position.x - 4.0 and sp.x <= r.end.x + 4.0 and sp.y >= r.position.y - 4.0 and sp.y <= r.end.y + 4.0:
			return f
		var s: Vector2 = host.w2s(f.pos)
		var d := s.distance_to(sp)
		if d < maxf(28.0, 52.0 * host.cam_z) and d < bd:
			bd = d
			best = f
	return best

func click_at(sp: Vector2, btn: int, shift: bool) -> void:
	var f = hit_fleet(sp)
	var mg = host.motion_groups
	if btn == MOUSE_BUTTON_RIGHT:
		if f != null and f.side == 0:
			host.motion_panel.show_menu(f, sp)
		elif not host.my_sel().is_empty():
			cmds.order_move(host.s2w(sp))
		return
	if f != null and f.side == 0:
		var now := Time.get_ticks_msec()
		var again: bool = f.id == _last_fleet and now - _last_click < 450 and not host.multi
		_last_click = now
		_last_fleet = f.id
		mg.select_nodes([f.id if again else mg.top(f.id)], (shift or host.multi) and not again)
	elif not shift and not host.multi:
		mg.select_nodes([])

func box_select(a: Vector2, b: Vector2, additive: bool) -> void:
	host.motion_groups.select_nodes(host.motion_groups.box_nodes(a, b), additive or host.multi)

func _unhandled_input(event: InputEvent) -> void:
	if (event is InputEventMouseButton or event is InputEventMouseMotion) and event.device == InputEvent.DEVICE_ID_EMULATION:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		_key(event)
		return
	if host.G.state != "play":
		return
	if event is InputEventMouseButton and event.pressed:
		if host.motion_panel:
			host.motion_panel.hide_menu()
		match event.button_index:
			MOUSE_BUTTON_LEFT, MOUSE_BUTTON_MIDDLE:
				host.drag = {"s": event.position, "c": event.position, "btn": event.button_index, "moved": false, "mode": "", "shift": event.shift_pressed or event.ctrl_pressed, "last": event.position}
			MOUSE_BUTTON_WHEEL_UP:
				host._zoom(event.position, 1.12)
			MOUSE_BUTTON_WHEEL_DOWN:
				host._zoom(event.position, 1.0 / 1.12)

func _input(event: InputEvent) -> void:
	if (event is InputEventMouseButton or event is InputEventMouseMotion) and event.device == InputEvent.DEVICE_ID_EMULATION:
		return
	var drag: Dictionary = host.drag
	if host.G.state != "play" or drag.is_empty():
		return
	if event is InputEventMouseMotion:
		drag.c = event.position
		if not drag.moved and (drag.c as Vector2).distance_to(drag.s) > 6.0:
			drag.moved = true
			drag.mode = "box" if drag.btn == MOUSE_BUTTON_LEFT else "pan"
		if drag.mode == "pan":
			var d: Vector2 = event.position - (drag.last as Vector2)
			host.cam_pos -= d / host.cam_z
			host._clamp_cam()
		drag.last = event.position
	elif event is InputEventMouseButton and not event.pressed and event.button_index == drag.btn:
		if not drag.moved:
			click_at(drag.s, drag.btn, drag.shift)
		elif drag.mode == "box":
			box_select(drag.s, drag.c, drag.shift)
		host.drag = {}

func _key(e: InputEventKey) -> void:
	if e.keycode == KEY_F1:
		host.toggle_hud()
		return
	if e.keycode == KEY_SPACE:
		host._toggle_menu()
		return
	if host.G.state != "play":
		return
	var mg = host.motion_groups
	if e.keycode >= KEY_0 and e.keycode <= KEY_6:
		var n: int = e.keycode - KEY_0
		var mine: Array = host.alive(0)
		if n == 0:
			mg.select_nodes(mine.map(func(f): return mg.top(f.id)), e.shift_pressed)
		elif n <= host.logh7_pick_ids.size():
			mg.select_nodes([host.logh7_pick_ids[n - 1]], e.shift_pressed)
		return
	if e.keycode == KEY_ESCAPE:
		host.motion_panel.hide_menu()
		mg.select_nodes([])
		return
	var forms := {KEY_Q: "block", KEY_W: "line", KEY_E: "column", KEY_R: "echelon", KEY_T: "arc"}
	if forms.has(e.keycode):
		cmds.motion_form(forms[e.keycode])
		return
	if e.keycode == KEY_G:
		mg.group_selection()
		return
	if e.keycode == KEY_U:
		mg.ungroup_selection()
		return
	if e.keycode == KEY_B:
		cmds.motion_backward()
		return
	if e.ctrl_pressed or e.meta_pressed:
		return
	var key := OS.get_keycode_string(e.keycode)
	for c in host.CMDS:
		if c.key == key:
			cmds.do_cmd(c.id)
			return

# ---- 그룹 ----
func group_down(n: int) -> void:
	_group_press[n] = Time.get_ticks_msec()

func group_up(n: int) -> void:
	var held := Time.get_ticks_msec() - int(_group_press.get(n, 0))
	if held >= 600:
		assign_group(n)
	else:
		select_group(n)

func group_fleets(n: int) -> Array:
	SelectionSet.prune(host.groups, host.by_id)
	var out: Array = []
	for id in host.groups.get(n, []):
		out.append(host.by_id(id))
	return out

func same_sel(g: Array) -> bool:
	return SelectionSet.same(g, host.selected)

func select_group(n: int) -> void:
	if host.G.state != "play":
		return
	var g := group_fleets(n)
	if g.is_empty():
		host.toast("비어 있는 편성입니다 · 번호 버튼을 길게 눌러 저장")
		return
	if same_sel(g):
		var c := Vector2.ZERO
		for f in g:
			c += f.pos
		host.cam_pos = c / g.size()
	host.selected.assign(g)
	host.inspect = null
	host.refresh_panel()

func assign_group(n: int) -> void:
	var s: Array = host.my_sel()
	if s.is_empty():
		host.toast("저장할 함대를 먼저 선택하세요")
		return
	host.groups[n] = SelectionSet.ids(s)
	host.toast("편성 %d에 %d개 전대 저장" % [n, s.size()])
