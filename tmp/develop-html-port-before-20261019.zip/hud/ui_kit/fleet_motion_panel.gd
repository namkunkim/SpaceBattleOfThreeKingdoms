extends CanvasLayer

const FORMS := {"block": "덩어리", "line": "가로줄", "column": "세로줄", "echelon": "사선", "arc": "호"}
var battle: Node
var bar: HBoxContainer
var popup: PopupPanel
var help_box: PanelContainer
var info: Label
var logs: VBoxContainer
var option_buttons := {}
var old_moves := {}
var log_items: Array = []
var pending_forms := {}
var form_buttons := {}

func setup(b: Node) -> void:
	battle = b
	layer = 9
	bar = HBoxContainer.new()
	bar.position = Vector2(332, 16)
	add_child(bar)
	button(bar, "재시작", func(): battle._restart())
	for key in ["combat", "flip", "preview", "stretch", "rings", "help"]:
		var title: String = {"combat": "교전", "flip": "제자리 반전", "preview": "도착 미리보기", "stretch": "이동 늘림", "rings": "윤곽 항상", "help": "도움말"}[key]
		var bopt := button(bar, title, func(): toggle_option(key))
		bopt.toggle_mode = true
		option_buttons[key] = bopt
	popup = PopupPanel.new()
	popup.name = "FleetMotionMenu"
	add_child(popup)
	help_box = PanelContainer.new()
	help_box.position = Vector2(332, 64)
	add_child(help_box)
	var label := Label.new()
	label.add_theme_font_size_override("font_size", 13)
	label.text = "왼쪽 클릭: 묶음 선택 · 더블클릭: 함대만 · Shift/Ctrl: 추가·빼기\n왼쪽 끌기: 상자(묶음 일부면 함대별) · 우클릭: 이동\n오른쪽 끌기: 시작점으로 이동 + 끈 방향으로 도착 · 아군 우클릭: 메뉴\n터치: 아군 탭 선택 · 빈 곳 탭 이동 · 끌기 방향 지정 · 길게 누르기 메뉴\n1~6 함대 / 0 전체 · Q W E R T 대열 모양 · B 후진 · X 전술 퇴각 · S 정지 · G 묶기 · U 해제 · Esc\n묶음 안 함대의 개별 이동·후진·공격은 이탈, 진형 변경·정지는 묶음 유지\n제자리 반전: 90° 초과면 함선 위치 유지 · 접적: 배치 유지, 함선은 적 조준\n대열 모양은 배치만 변경 · 전투 진형 효과 유지 · 교전은 켜진 상태로 시작"
	help_box.add_child(label)
	info = Label.new()
	info.position = Vector2(332, 238)
	info.add_theme_font_size_override("font_size", 14)
	add_child(info)
	logs = VBoxContainer.new()
	logs.position = Vector2(332, 302)
	logs.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(logs)
	battle.battle_event.connect(_event)
	get_viewport().size_changed.connect(_layout)
	_layout()

func button(parent: Node, title: String, action: Callable) -> Button:
	var b := Button.new()
	b.text = title
	b.custom_minimum_size = Vector2(44, 40)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(action)
	parent.add_child(b)
	return b

func toggle_option(key: String) -> void:
	battle.logh7_options[key] = not battle.logh7_options[key]
	if key == "combat" or key == "flip":
		battle.issue(BattleCommands.make("motion_options", [], -1, Vector2.ZERO, {"enabled": true, "flip": battle.logh7_options.flip, "combat": battle.logh7_options.combat}))

func _layout() -> void:
	var width := get_viewport().get_visible_rect().size.x
	# 옵션은 작은 화면에서 2행으로 나눠 모두 접근할 수 있게 한다.
	var x := 16.0 if width < 1200 else 332.0
	bar.position = Vector2(x, 132 if width < 1200 else 16)
	var available := width - x - 16.0
	var step := available / maxf(1.0, bar.get_child_count())
	for b in bar.get_children():
		b.add_theme_font_size_override("font_size", 11 if step < 105 else 13)
	help_box.position = Vector2(x, bar.position.y + 46)
	info.position = Vector2(x, help_box.position.y + 172)
	logs.position = info.position + Vector2(0, 64)

func show_menu(f, point: Vector2) -> void:
	var mg = battle.motion_groups
	if f != null and f.side == 0 and not battle.selected.has(f):
		mg.select_nodes([mg.top(f.id)])
	if battle.my_sel().is_empty():
		return
	for child in popup.get_children():
		popup.remove_child(child)
		child.queue_free()
	var col := VBoxContainer.new()
	popup.add_child(col)
	var title := Label.new()
	var chosen: Array = mg.selection()
	title.text = mg.node_name(chosen[0]) if chosen.size() == 1 else "%d개 선택" % chosen.size()
	col.add_child(title)
	form_buttons.clear()
	for key in FORMS:
		var form_button := button(col, "대열 · " + FORMS[key], func(): battle.cmds.motion_form(key); popup.hide())
		form_button.toggle_mode = true
		form_button.set_pressed_no_signal(selection_form(chosen) == key)
		form_buttons[key] = form_button
	button(col, "후진 (B)", func(): battle.cmds.motion_backward(); popup.hide())
	button(col, "정지", func(): battle.cmds.do_cmd("stop"); popup.hide())
	if chosen.size() >= 2:
		button(col, "선택 묶기", func(): mg.group_selection(); popup.hide())
	if chosen.any(func(id): return mg.nodes.has(id)):
		button(col, "묶음 해제", func(): mg.ungroup_selection(); popup.hide())
	if f != null and f.side == 0:
		button(col, "%s만 선택" % f.fname, func(): mg.select_nodes([f.id]); popup.hide())
	popup.reset_size()
	var sz := popup.get_contents_minimum_size()
	var vs := get_viewport().get_visible_rect().size
	popup.position = Vector2i(clampf(point.x + 4, 4, maxf(4, vs.x - sz.x - 4)), clampf(point.y + 4, 4, maxf(4, vs.y - sz.y - 4)))
	popup.popup()

func hide_menu() -> void:
	popup.hide()

func _event(kind: String, message: String, _fid: int) -> void:
	if kind != "toast":
		return
	var label := Label.new()
	label.text = message
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	logs.add_child(label)
	logs.move_child(label, 0)
	log_items.push_front({"label": label, "left": 5.7})
	while log_items.size() > 6:
		var expired: Dictionary = log_items.pop_back()
		expired.label.queue_free()

func reset() -> void:
	hide_menu()
	old_moves.clear()
	pending_forms.clear()
	for item in log_items:
		item.label.queue_free()
	log_items.clear()

func _process(dt: float) -> void:
	if battle == null:
		return
	var on: bool = battle.G.get("state", "") == "play" and not battle.hud_hidden
	bar.visible = on
	help_box.visible = on and battle.logh7_options.help
	info.visible = on
	logs.visible = on
	if not on:
		popup.hide()
	for key in option_buttons:
		option_buttons[key].set_pressed_no_signal(battle.logh7_options[key])
	for item in log_items.duplicate():
		item.left -= dt
		item.label.modulate.a = clampf(item.left / 0.7, 0, 1)
		if item.left <= 0:
			item.label.queue_free()
			log_items.erase(item)
	var names := []
	var count := 0
	var total := 0
	var recon := 0
	var forms := []
	var statuses := []
	for f in battle.my_sel():
		names.append(f.fname)
		count += int(f.ships)
		total += int(f.max_ships)
		recon += int(f.recon_ships)
		var form: String = FORMS.get(f.visual_motion_form, FORMS.block)
		if not forms.has(form):
			forms.append(form)
		var status := fleet_status(f)
		if not statuses.has(status):
			statuses.append(status)
	var chosen: Array = battle.motion_groups.selection()
	var group_form := ""
	if chosen.size() == 1 and battle.motion_groups.nodes.has(chosen[0]):
		group_form = " · 묶음 대열 " + str(FORMS.get(battle.motion_groups.nodes[chosen[0]].form, "자유 배치"))
	info.text = " · ".join(names) + ("\n대열 %s%s · %s\n함선 %d/%d · 정찰함 %d척" % ["·".join(forms), group_form, "·".join(statuses), count, total, recon] if not names.is_empty() else "")
	for f in battle.fleets:
		if f.side != 0:
			continue
		if old_moves.get(f.id, false) and not f.has_move and not f.dead:
			battle.toast("%s: 이동 완료" % f.fname)
		old_moves[f.id] = f.has_move
	var renderer = battle.presentation.renderer if battle.presentation else null
	for fid in pending_forms.keys():
		var f = battle.by_id(fid)
		if f == null or f.dead:
			pending_forms.erase(fid)
		elif renderer and renderer.vis.has(fid):
			var v = renderer.vis[fid]
			if v.motion_form == pending_forms[fid] and v.form_elapsed >= 5.0:
				battle.toast("%s: %s 대열 전환 완료" % [f.fname, FORMS.get(pending_forms[fid], "")])
				pending_forms.erase(fid)

func watch_form(ids: Array, key: String) -> void:
	for fid in ids:
		pending_forms[fid] = key

func selection_form(chosen: Array) -> String:
	if chosen.size() == 1 and battle.motion_groups.nodes.has(chosen[0]):
		return battle.motion_groups.nodes[chosen[0]].form
	var result := ""
	for f in battle.my_sel():
		var current: String = f.visual_motion_form if f.visual_motion_form != "" else "block"
		if result != "" and result != current:
			return ""
		result = current
	return result

func fleet_status(f) -> String:
	if f.flip_hold_s > 0:
		return "제자리 반전 중"
	if f.motion_contact:
		return "접적 이동" if f.has_move else "접적 대기"
	if f.has_move:
		return "후진 중" if f.strafe else "항행 중"
	if pending_forms.has(f.id):
		return "대열 전환 중"
	return "정지"

func over_hud(point: Vector2) -> bool:
	return bar.visible and bar.get_global_rect().has_point(point) or help_box.visible and help_box.get_global_rect().has_point(point)
