extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _sim() -> BattleSim:
	var F := SalvoFixture
	return F.sim([F.def("A", 400, 300, [["SHP-04", 8]], true), F.def("B", 400, 600, [["SHP-04", 8]])], [F.def("C", 1500, 800, [["SHP-04", 8]], true)])

func _run() -> void:
	var s := _sim()
	var a: FleetState = s.st.fleets[0]
	var b: FleetState = s.st.fleets[1]
	var original_form := a.formation_id
	var original_speed := a.speed
	var before_rules := JSON.stringify(s.salvo.C)
	s.issue(BattleSim.command(0, [a.id], "motion_form", -1, Vector2.ZERO, {"form": "arc"}))
	if not TestCheck.ok(self, a.visual_motion_form == "arc" and a.formation_id == original_form and a.speed == original_speed and a.form_to == "", "visual shape preserves combat formation and speed"): return
	if not TestCheck.ok(self, JSON.stringify(s.salvo.C) == before_rules, "canonical combat values unchanged"): return
	var targets := {a.id: Vector2(800, 300), b.id: Vector2(600, 600)}
	s.issue(BattleSim.command(0, [a.id, b.id], "move", -1, Vector2(700, 450), {"destinations": targets, "destination_facings": {a.id: PI / 2.0, b.id: 0.0}, "sync_arrival": true, "logh7": true}))
	if not TestCheck.ok(self, a.move_to == targets[a.id] and b.move_to == targets[b.id], "individual destinations preserved"): return
	if not TestCheck.ok(self, is_equal_approx(400.0 / a.speed_cap, 200.0 / b.speed_cap), "distance-based common arrival duration"): return
	if not TestCheck.ok(self, a.face_set and b.face_set and absf(a.face_to - PI / 2.0) < 0.001 and b.face_to == 0.0, "nested group per-fleet arrival facing"): return
	# A 180 degree reference flip with negated slots leaves every world slot fixed.
	a.layout_ready = true
	a.layout_heading = 0.0
	a.heading = 0.0
	var off := Vector2(30, 17)
	var before := a.pos + off.rotated(a.layout_heading) * a.slot_sign
	s._motion_face(a, PI)
	var after := a.pos + off.rotated(a.layout_heading) * a.slot_sign
	if not TestCheck.ok(self, before.distance_to(after) < 0.0001 and a.slot_sign == -1 and a.flip_hold_s > 0.0, "flip preserves world slot and holds motion"): return
	var h := a.heading
	if not TestCheck.ok(self, absf(BattleRules.ang_diff(h, a.layout_heading)) < 0.0001, "flip synchronizes combat and layout heading"): return
	# Contact movement keeps the shape axis; known enemy alone controls aim.
	a.flip_hold_s = 0.0
	var layout := a.layout_heading
	var foe: FleetState = s.st.fleets[2]
	foe.pos = a.pos + Vector2(100, 0)
	var start := a.pos
	s._motion_step(a, true, a.pos + Vector2(0, 100), a.speed, foe)
	if not TestCheck.ok(self, a.layout_heading == layout and a.pos.y > start.y and a.pos.x == start.x, "contact uses parallel translation without rotating layout"): return
	var proj := s.projection(0)
	var vm := BattleViewModel.new()
	vm.apply(proj)
	if not TestCheck.ok(self, absf(vm.fleet(a.id).face_to - PI / 2.0) < 0.001 and vm.fleet(b.id).face_set, "VM arrival preview retains per-fleet radian facing and active state"): return
	if not TestCheck.ok(self, proj.squadrons[0].slot_sign == -1 and proj.squadrons[0].visual_motion_form == "arc", "projection retains stable slot sign and visual shape"): return
	var fp := s.fingerprint()
	s.issue(BattleSim.command(0, [], "motion_options", -1, Vector2.ZERO, {"combat": false}))
	if not TestCheck.ok(self, not s.motion_combat_enabled and s.fingerprint() != fp and s.command_log.back().kind == "motion_options", "combat option recorded and fingerprinted"): return
	if not _behaviour() or not _fog() or not _replay(): return
	if not _recon_projection(): return
	if not _runtime_activation(): return
	if not _review_r1_r7(): return
	print("LOGH7_MOTION_PASS")
	quit(0)

func _ticks(s: BattleSim, n: int) -> void:
	for i in n:
		s.step()
		s.drain_events()

func _behaviour() -> bool:
	var s := _sim()
	s.motion_combat_enabled = false
	var a: FleetState = s.st.fleets[0]
	a.heading = 0.0
	var start := a.pos
	s.issue(BattleSim.command(0, [a.id], "move", -1, start - Vector2(120, 0), {"logh7": true}))
	_ticks(s, 9)
	if not TestCheck.ok(self, a.pos.distance_to(start) < 0.001 and a.flip_hold_s > 0.0, "issue-step flip holds position for first 0.9 seconds"): return false
	for i in 1000:
		s.step()
		if not a.has_move: break
	if not TestCheck.ok(self, not a.has_move and a.pos.distance_to(start - Vector2(120, 0)) < 0.01, "flip releases and reaches destination"): return false
	s = _sim()
	s.motion_combat_enabled = false
	a = s.st.fleets[0]
	var b: FleetState = s.st.fleets[1]
	a.heading = 0.0
	b.heading = 0.0
	s.issue(BattleSim.command(0, [a.id, b.id], "move", -1, Vector2.ZERO, {"logh7": true, "sync_arrival": true, "destinations": {a.id: a.pos + Vector2(240, 0), b.id: b.pos + Vector2(120, 0)}}))
	var arrivals := [-1, -1]
	for i in 2000:
		s.step()
		if arrivals[0] < 0 and not a.has_move: arrivals[0] = s.st.tick
		if arrivals[1] < 0 and not b.has_move: arrivals[1] = s.st.tick
		if arrivals[0] >= 0 and arrivals[1] >= 0: break
	if not TestCheck.ok(self, arrivals[0] >= 0 and arrivals[1] >= 0 and absi(arrivals[0] - arrivals[1]) <= 3, "actual distance-scaled arrival times: %s" % str(arrivals)): return false
	s = _sim()
	s.motion_combat_enabled = false
	a = s.st.fleets[0]
	b = s.st.fleets[1]
	s.issue(BattleSim.command(0, [a.id, b.id], "move", -1, Vector2.ZERO, {"logh7": true, "sync_arrival": true, "destinations": {a.id: Vector2(-100, a.pos.y), b.id: Vector2(200, b.pos.y)}}))
	if not TestCheck.ok(self, a.move_to.x == s.R.edge and is_equal_approx(a.pos.distance_to(a.move_to) / a.speed_cap, b.pos.distance_to(b.move_to) / b.speed_cap), "boundary-clamped targets determine synchronized speed"): return false
	a.heading = 0.0
	a.layout_ready = false
	s.issue(BattleSim.command(0, [a.id], "move", -1, a.pos - Vector2(120, 0), {"logh7": true, "flip": false}))
	s.step()
	if not TestCheck.ok(self, a.slot_sign == 1 and a.flip_hold_s == 0.0 and absf(a.heading) <= deg_to_rad(float(s.salvo.C.movement.turn_deg_per_s)) / s.st.hz + 0.001, "flip off keeps canonical turn-rate limit"): return false
	a.energy_m = 0
	a.heat_m = 1000
	var hulls := [a.hull, s.st.fleets[2].hull]
	s.issue(BattleSim.command(0, [a.id], "formation", -1, Vector2.ZERO, {"id": "FRM-02"}))
	var left := a.form_left
	_ticks(s, 10)
	if not TestCheck.ok(self, a.form_left < left and a.energy_m > 0 and a.heat_m < 1000 and a.hull == hulls[0] and s.st.fleets[2].hull == hulls[1], "combat off permits recovery and formation progress without salvo damage"): return false
	return true

func _fog() -> bool:
	var F := SalvoFixture
	var full := F.combat()
	var s := F.sim([F.def("A", 400, 450, [["SHP-01", 10]], true)], [F.def("B", 1500, 450, [["SHP-02", 4]], true)], 1, "", func(cb): cb.detection = full.detection)
	s.motion_combat_enabled = false
	var a: FleetState = s.st.fleets[0]
	var b: FleetState = s.st.fleets[1]
	_ticks(s, 10)
	if not TestCheck.ok(self, s.projection(0).squadrons.size() == 1, "undetected actual enemy absent from projection"): return false
	b.pos = Vector2(500, 450)
	_ticks(s, 10)
	if not TestCheck.ok(self, s.detect.can_target(0, b.id), "canonical sensor acquires contact"): return false
	s.issue(BattleSim.command(0, [a.id], "move", -1, a.pos + Vector2(0, 20), {"logh7": true, "facing_deg": 180.0}))
	s.step()
	var layout := a.layout_heading
	_ticks(s, 5)
	if not TestCheck.ok(self, a.motion_contact and a.layout_heading == layout and not a.face_set, "contact locks layout and ignores arrival facing"): return false
	if not TestCheck.ok(self, absf(BattleRules.ang_diff(a.heading, (s.known_pos(a, b) - a.pos).angle())) < 0.02, "actual combat heading follows public contact aim"): return false
	b.pos = Vector2(1500, 450)
	_ticks(s, 10)
	for q in s.projection(0).squadrons:
		if q.id == b.id:
			if not TestCheck.ok(self, q.pos != b.pos and not q.has("layout_heading"), "contact does not leak lost actual position or layout"): return false
	return true

func _replay() -> bool:
	var F := SalvoFixture
	var cb := F.combat()
	cb.erase("detection")
	cb.erase("terrain")
	cb.erase("supply")
	var profile := {"profile_id": "motion-replay", "rules": PocSetup.profile().rules, "combat": cb, "ally": [F.def("A", 400, 300, [["SHP-04", 8]], true)], "foe": [F.def("B", 1500, 800, [["SHP-04", 8]], true)], "reinf": []}
	var s := BattleSim.new(4, 10, profile)
	var id: int = s.st.fleets[0].id
	s.issue(BattleSim.command(0, [], "motion_options", -1, Vector2.ZERO, {"enabled": true, "flip": true, "combat": false}))
	s.issue(BattleSim.command(0, [id], "move", -1, Vector2(280, 300), {"logh7": true}))
	s.issue(BattleSim.command(0, [id], "motion_form", -1, Vector2.ZERO, {"form": "line"}))
	s.issue(BattleSim.command(0, [], "motion_options", -1, Vector2.ZERO, {"combat": false}))
	_ticks(s, 40)
	var replay := BattleSim.replay(4, 10, s.command_log, 40, profile)
	return TestCheck.ok(self, replay.fingerprint() == s.fingerprint(), "motion and option command replay produces identical fingerprint")

func _recon_projection() -> bool:
	var F := SalvoFixture
	var s := F.sim([F.def("Recon", 400, 450, [["SHP-08", 2, "FAST-EQ-RECON"]], true)], [F.def("Enemy", 1400, 450, [["SHP-08", 3, "FAST-EQ-RECON"]], true)])
	var p := s.projection(0)
	var vm := BattleViewModel.new()
	vm.apply(p)
	if not TestCheck.ok(self, p.squadrons[0].recon_ships == 2 and vm.fleet(s.st.fleets[0].id).recon_ships == 2, "canonical surviving recon count reaches allied VM"): return false
	if not TestCheck.ok(self, not p.squadrons[1].has("recon_ships"), "enemy projection does not disclose recon composition"): return false
	s.st.fleets[0].stages["SHP-08"] = [1, 0, 0, 0, 1]
	return TestCheck.ok(self, s.projection(0).squadrons[0].recon_ships == 1, "departed recon ships are excluded from marker count")

func _runtime_activation() -> bool:
	var s := _sim()
	if not TestCheck.ok(self, not s.motion_runtime_enabled and not s.st.fleets[0].motion_enabled, "legacy core fixtures keep motion mode off by default"): return false
	var fp := s.fingerprint()
	s.issue(BattleSim.command(0, [], "motion_options", -1, Vector2.ZERO, {"enabled": true, "flip": false, "combat": false}))
	for f in s.st.fleets:
		if not TestCheck.ok(self, f.motion_enabled and not f.motion_flip, "runtime activation includes both sides without changing AI control"): return false
	if not TestCheck.ok(self, s.fingerprint() != fp, "global runtime and flip options enter state fingerprint"): return false
	s._reinf_def = [SalvoFixture.def("Reinforcement", 1400, 200, [["SHP-04", 4]])]
	s.debug_spawn_reinf()
	var reinforcement: FleetState = s.st.fleets.back()
	if not TestCheck.ok(self, reinforcement.motion_enabled and not reinforcement.motion_flip, "reinforcements inherit active runtime options"): return false
	s.issue(BattleSim.command(0, [], "motion_options", -1, Vector2.ZERO, {"flip": true}))
	return TestCheck.ok(self, not s.motion_combat_enabled and s.motion_runtime_enabled and reinforcement.motion_flip, "partial option updates preserve combat and enabled state")

# 첫 독립 5-b 반려 수정 round: R1 비정180도 반전 보류, R7 접촉 상실 후 정지 조준 복귀.
func _review_r1_r7() -> bool:
	var s := _sim()
	s.motion_combat_enabled = false
	var a: FleetState = s.st.fleets[0]
	a.heading = 0.0
	var origin := a.pos
	var local_slot := Vector2(30, 17)
	var slot_before := origin + local_slot
	var goal := origin + Vector2(-120, 120)
	s.issue(BattleSim.command(0, [a.id], "move", -1, goal, {"logh7": true}))
	s.step()
	var held_layout := a.layout_heading
	var held_heading := a.heading
	if not TestCheck.ok(self, a.flip_hold_s > 0.0 and a.slot_sign == -1, "R1 135 degree command starts in-place flip hold"): return false
	for i in 8:
		s.step()
		var world_slot := a.pos + (local_slot * a.slot_sign).rotated(a.layout_heading)
		if not TestCheck.ok(self, a.pos == origin and a.layout_heading == held_layout and a.heading == held_heading and world_slot.distance_to(slot_before) < 0.0001, "R1 center, heading and slot stay fixed during 135 degree flip hold"): return false
	for i in 1500:
		s.step()
		if not a.has_move: break
	if not TestCheck.ok(self, not a.has_move and a.pos.distance_to(goal) < 0.01, "R1 residual 45 degree turn resumes after hold and reaches actual destination"): return false
	s = _sim()
	s.motion_combat_enabled = false
	a = s.st.fleets[0]
	var foe: FleetState = s.st.fleets[2]
	a.heading = 0.0
	a.layout_heading = 0.0
	a.layout_ready = true
	foe.pos = a.pos + Vector2(0, -100)
	s.issue(BattleSim.command(0, [], "motion_options", -1, Vector2.ZERO, {"enabled": true, "combat": false}))
	s.step()
	if not TestCheck.ok(self, a.motion_contact and absf(BattleRules.ang_diff(a.heading, -PI / 2.0)) < 0.001 and a.layout_heading == 0.0, "R7 stationary fleet aims at public northern contact without rotating layout"): return false
	foe.pos = Vector2(1500, 800)
	s.step()
	var p := s.projection(0)
	var vm := BattleViewModel.new()
	vm.apply(p)
	return TestCheck.ok(self, not a.motion_contact and a.heading == a.layout_heading and a.layout_heading == 0.0 and vm.fleet(a.id).aim_heading == 0.0 and vm.fleet(a.id).contact_id == -1, "R7 no-command contact loss restores combat and projected ship aim to preserved layout")

