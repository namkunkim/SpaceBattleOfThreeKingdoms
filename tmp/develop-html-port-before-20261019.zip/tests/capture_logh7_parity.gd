extends SceneTree
# 화면 검증 전용. 헤드리스 일반 게이트가 아니다.
# godot --path . --resolution 1600x900 -s tests/capture_logh7_parity.gd -- res://out/logh7-1600
# 1280x720에서도 같은 도구를 실행한다. PNG와 실제 코어 조건 JSON을 함께 남긴다.
var battle: Node
var renderer: FleetRenderer
var deck: Control
var out_dir := ""
var measurements := []
var fails := 0
var ids: Array = []

func _initialize() -> void:
	call_deferred("_run")

func check(ok: bool, what: String) -> void:
	if not ok:
		fails += 1
		push_error("LOGH7_CAPTURE_FAIL " + what)

func _step(n: int) -> void:
	for i in n:
		battle.update_sim(0.05)
		battle.vm.interpolate(1.0)
		renderer.update(0.05)
		battle.rig.update()
		await process_frame

func _save(stage: String, extra := {}) -> void:
	deck.overlay.queue_redraw()
	await process_frame
	await RenderingServer.frame_post_draw
	var file := out_dir.path_join(stage + ".png")
	check(root.get_texture().get_image().save_png(file) == OK, stage + " PNG 저장")
	var fleets := []
	for f in battle.my_sel():
		var sq := renderer.src.squadron(f.id)
		var v: FleetRenderer.FleetVis = renderer.vis[f.id]
		fleets.append({"id": f.id, "position": [sq.pos.x, sq.pos.y], "heading": sq.heading,
			"layout_heading": sq.layout_heading, "slot_sign": sq.slot_sign, "flip_hold_s": sq.flip_hold_s,
			"motion_contact": sq.motion_contact, "contact_id": sq.contact_id,
			"motion_speed": sq.motion_speed, "motion_max_speed": sq.motion_max_speed,
			"visual_form": v.motion_form, "form_elapsed": v.form_elapsed,
			"slots": v.slots.size(), "living_slots": v.alive_n,
			"preview_slots": renderer.destination_slots(f.id).size(),
			"stretch": renderer._slot_scale(sq).z})
	measurements.append({"stage": stage, "size": [root.size.x, root.size.y], "fleets": fleets,
		"groups": battle.logh7_groups, "options": battle.logh7_options.duplicate(),
		"clock": battle.sim.st.clock_s(), "extra": extra, "fingerprint": battle.sim.fingerprint()})
	print("LOGH7_CAPTURE ", stage, " ", file)

func _run() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("화면 있는 Godot 실행이 필요한 캡처 도구입니다")
		quit(2)
		return
	var args := OS.get_cmdline_user_args()
	out_dir = ProjectSettings.globalize_path(args[0] if not args.is_empty() else "res://out/logh7-parity")
	DirAccess.make_dir_recursive_absolute(out_dir)
	root.gui_disable_input = true
	root.gui_embed_subwindows = true
	battle = (load("res://scenes/FleetBattle3D.tscn") as PackedScene).instantiate()
	root.add_child(battle)
	for i in 6:
		await process_frame
	deck = battle.presentation.hud
	deck.guard.enabled = false
	deck.begin_battle()
	battle.set_process(false)
	battle.presentation.set_process(false)
	deck.pacing.set_process(false)
	battle.G.speed = 1
	battle.G.slow = 1.0
	renderer = battle.presentation.renderer
	battle.sim.st.ai_timer = 1 << 40
	var mine: Array = battle.alive(0)
	check(mine.size() >= 3, "실제 적벽 아군 3함대")
	if mine.size() < 3:
		quit(1)
		return
	for i in 3:
		ids.append(mine[i].id)
	var field: Vector2 = battle.FIELD_SIZE
	for core in battle.sim.st.fleets:
		core.pos = field - Vector2(80, 80) if core.side == 1 else Vector2(60, 60)
		core.home = core.pos
		core.has_move = false
		core.target_id = -1
		core.face_set = false
		core.route.clear()
		core.wait = 9000
		core.control = "direct"
	for i in ids.size():
		var core = battle.sim.st.by_id(ids[i])
		core.pos = Vector2(650 + i * 180, 600)
		core.home = core.pos
		core.heading = 0.0
	battle._sync()
	battle.vm.interpolate(1.0)
	renderer.reset()
	renderer.update(0.0)
	battle.cam_pos = Vector2(870, 670)
	battle.cam_z = 1.1
	battle.rig.update()
	deck._set_info_open(false)
	battle.motion_panel.toggle_option("combat")
	battle.motion_groups.select_nodes(ids)
	battle.motion_groups.group_selection()
	check(battle.logh7_groups.size() == 1, "실제 묶음 생성")
	await _save("01-selected-group")
	battle.cmds.motion_form("line")
	await _step(110)
	check(renderer.vis[ids[0]].motion_form == "line", "묶음 목표 가로줄 표시")
	await _save("02-group-line")
	battle.cmds.order_move(Vector2(1160, 700))
	await _step(20)
	check(battle.my_sel().any(func(f): return f.has_move), "실제 묶음 이동")
	await _save("03-moving-preview-stretch")
	battle.motion_groups.select_nodes([ids[0]])
	battle.cmds.do_cmd("stop")
	await _step(5)
	var f = battle.by_id(ids[0])
	battle.cmds.order_face(f.heading + PI)
	await _step(8)
	check(battle.sim.st.by_id(f.id).flip_hold_s > 0.0, "제자리 반전 이동 정지")
	await _save("04-flip-half")
	await _step(16)
	var fixed := ReferenceMotionFixture.prepare(battle, false)
	check(not fixed.is_empty(), "정본 센서 자연 접촉 fixture")
	if not fixed.is_empty():
		battle.motion_groups.reset()
		battle.motion_groups.select_nodes([fixed.ally_id])
		f = battle.by_id(fixed.ally_id)
		battle.cam_pos = Vector2(750, 500)
		battle.cam_z = 1.6
		battle.cmds.order_move(f.pos + Vector2(0, 80))
		await _step(15)
		check(battle.by_id(f.id).motion_contact, "공개 접촉과 평행 이동")
		await _save("05-contact-parallel", fixed)
		var start := Vector2(root.size) * Vector2(0.7, 0.65)
		var pressed := InputEventMouseButton.new()
		pressed.button_index = MOUSE_BUTTON_RIGHT
		pressed.pressed = true
		pressed.position = start
		battle.motion_mouse._unhandled_input(pressed)
		var dragged := InputEventMouseMotion.new()
		dragged.position = start + Vector2(80.0, -70.0)
		battle.motion_mouse._input(dragged)
		check(battle.presentation.touch.order.has("motion_face"), "실제 우드래그 방향 미리보기 생성")
		await _save("06-drag-arrival-direction")
		var released := InputEventMouseButton.new()
		released.button_index = MOUSE_BUTTON_RIGHT
		released.pressed = false
		released.position = dragged.position
		battle.motion_mouse._input(released)
		battle.motion_panel.show_menu(f, Vector2(root.size) * Vector2(0.62, 0.3))
		await _save("07-context-menu-help")
		battle.motion_panel.hide_menu()
		battle.motion_panel.toggle_option("help")
		await _save("08-help-hidden")
	var output := FileAccess.open(out_dir.path_join("conditions.json"), FileAccess.WRITE)
	output.store_string(JSON.stringify({"fails": fails, "measurements": measurements}, "\t"))
	print("LOGH7_CAPTURE_", "PASS" if fails == 0 else "FAIL")
	quit(1 if fails else 0)
