extends SceneTree

# 사용자 확정 PoC 계약으로 구형 터치 기대를 교체한다(2026-10-18).
# 선택/실제 주문/취소/상자/핀치/메뉴/HUD 누수 회귀를 삭제하지 않고 실제 InputEvent로 검증한다.
# 아군에서 끌기는 상자, 선택후 빈 곳 끌기는 시작점 이동+도착 방향, 길게 누르기는 메뉴다.

func _initialize() -> void:
	call_deferred("_run")

func _touch(idx: int, p: Vector2, down: bool, cancel := false) -> void:
	var e := InputEventScreenTouch.new()
	e.index = idx
	e.position = p
	e.pressed = down
	e.canceled = cancel
	root.push_input(e, true)

func _move(idx: int, a: Vector2, b: Vector2, steps := 8) -> void:
	for i in steps:
		var e := InputEventScreenDrag.new()
		e.index = idx
		e.position = a.lerp(b, float(i + 1) / steps)
		e.relative = (b - a) / steps
		root.push_input(e, true)
		Input.flush_buffered_events()

func _settle() -> void:
	Input.flush_buffered_events()
	await process_frame
	await process_frame

func _run() -> void:
	var battle := (load("res://scenes/FleetBattle3D.tscn") as PackedScene).instantiate()
	root.add_child(battle)
	await process_frame
	var deck = battle.presentation.hud
	if not TestCheck.ok(self, deck != null and battle.presentation.touch != null, "presentation"): return
	deck.begin_battle()
	deck.visible = false
	battle.logh7_options.help = false
	battle.G.hold = true
	battle.cam_z = 0.8
	battle.cam_pos = battle.field() * 0.5
	var allies: Array = battle.alive(0)
	var f = allies[0]
	var g = allies[1]
	for i in allies.size():
		TestPoke.fleet(battle, allies[i], {"pos": Vector2(1400, 950), "has_move": false})
	TestPoke.fleet(battle, f, {"pos": Vector2(550, 650), "has_move": false})
	TestPoke.fleet(battle, g, {"pos": Vector2(750, 650), "has_move": false})
	await _settle()
	var sp: Vector2 = battle.w2s(f.pos)
	battle.motion_groups.select_nodes([])
	_touch(0, sp, true)
	_touch(0, sp, false)
	await _settle()
	if not TestCheck.ok(self, battle.selected == [f], "tap select"): return
	if not TestCheck.ok(self, battle.drag.is_empty(), "no emulated mouse box from tap"): return
	var empty := Vector2.ZERO
	for candidate in [Vector2(950, 440), Vector2(1050, 550), Vector2(900, 650), Vector2(1100, 450)]:
		if battle._hit_fleet(candidate) == null and not battle.presentation.touch._over_hud(candidate) and not battle.motion_panel.over_hud(candidate):
			empty = candidate
			break
	if not TestCheck.ok(self, empty != Vector2.ZERO, "empty command location"): return
	var dst := empty + Vector2(70, 80)
	_touch(0, empty, true)
	_move(0, empty, dst)
	await _settle()
	if not TestCheck.ok(self, not battle.presentation.touch.order.is_empty() and battle.presentation.touch.order.has("motion_face"), "order direction preview"): return
	_touch(0, dst, false)
	await _settle()
	var command: Dictionary = battle.sim.command_log.back()
	if not TestCheck.ok(self, command.kind == "move" and command.args.get("logh7", false) and f.move_to.distance_to(battle.s2w(empty)) < 1.0, "drag move uses start point"): return
	var expected: float = (battle.s2w(dst) - battle.s2w(empty)).angle()
	if not TestCheck.ok(self, absf(angle_difference(deg_to_rad(command.args.facing_deg), expected)) < 0.01, "drag end selects arrival heading"): return
	# OS/pointer 취소는 명령을 내지 않고 미리보기와 선택 상자를 정리한다.
	TestPoke.fleet(battle, f, {"has_move": false})
	var n: int = battle.sim.command_log.size()
	_touch(0, empty, true)
	_move(0, empty, dst)
	_touch(0, dst, false, true)
	await _settle()
	if not TestCheck.ok(self, battle.sim.command_log.size() == n and battle.presentation.touch.order.is_empty() and battle.drag.is_empty() and not f.has_move, "pointer cancel clears preview without order"): return
	# 아군에서 끌면 선택이 있어도 상자 선택. 화면 카메라는 움직이지 않는다.
	var cam0: Vector2 = battle.cam_pos
	var gp: Vector2 = battle.w2s(g.pos)
	_touch(0, sp, true)
	_move(0, sp, gp + Vector2(20, 20))
	await _settle()
	if not TestCheck.ok(self, battle.drag.get("mode", "") == "box", "ally drag box preview"): return
	_touch(0, gp + Vector2(20, 20), false)
	await _settle()
	if not TestCheck.ok(self, battle.selected.has(f) and battle.selected.has(g) and battle.cam_pos.is_equal_approx(cam0), "ally drag selects allies without pan"): return
	# 두 손가락 확대는 기존 카메라 입력을 유지한다.
	var z0: float = battle.cam_z
	_touch(0, empty, true)
	_touch(1, empty + Vector2(150, 0), true)
	_move(1, empty + Vector2(150, 0), empty + Vector2(300, 0))
	await _settle()
	_touch(1, empty + Vector2(300, 0), false)
	_touch(0, empty, false)
	await _settle()
	if not TestCheck.ok(self, battle.cam_z > z0 * 1.2, "pinch zoom"): return
	# 길게 누른 함대의 메뉴를 열고 버튼 수/명령 누수를 확인한다.
	gp = battle.w2s(g.pos)
	battle.motion_groups.select_nodes([g.id])
	n = battle.sim.command_log.size()
	_touch(0, gp, true)
	await create_timer(0.65).timeout
	_touch(0, gp, false)
	await _settle()
	if not TestCheck.ok(self, battle.motion_panel.popup.visible and battle.motion_panel.form_buttons.size() == 5 and battle.sim.command_log.size() == n, "long press context menu without order"): return
	battle.motion_panel.hide_menu()
	# HUD에서 시작한 손가락은 전장 명령/메뉴로 새지 않는다.
	var bar: Rect2 = battle.motion_panel.bar.get_global_rect()
	_touch(0, bar.position + Vector2(15, 15), true)
	_move(0, bar.position + Vector2(15, 15), empty)
	_touch(0, empty, false)
	await _settle()
	if not TestCheck.ok(self, battle.sim.command_log.size() == n and battle.presentation.touch.order.is_empty(), "HUD touch does not leak command"): return
	# 마우스 선택 경로도 새 터치 처리와 중복하지 않는다.
	gp = battle.w2s(g.pos)
	battle.motion_groups.select_nodes([])
	var mb := InputEventMouseButton.new()
	mb.button_index = MOUSE_BUTTON_LEFT
	mb.position = gp
	mb.pressed = true
	root.push_input(mb, true)
	var release := mb.duplicate()
	release.pressed = false
	root.push_input(release, true)
	await _settle()
	if not TestCheck.ok(self, battle.selected == [g], "mouse click select"): return
	print("TOUCH_INPUT_PASS")
	quit(0)
