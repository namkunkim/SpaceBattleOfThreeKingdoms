extends SceneTree
# LOGH7 표현 계약: 실제 렌더러를 쓰되 코어를 변경하지 않는 고정 슬롯·시각 기동 검사.
class PublicSource extends BattleSource:
	var public_squadrons := {}
	func squadron(id: int) -> Dictionary:
		return public_squadrons.get(id, {})

var fails := 0
func _initialize() -> void:
	call_deferred("_run")
func check(ok: bool, label_: String) -> void:
	if not ok:
		fails += 1
		push_error("LOGH7_VISUAL_FAIL " + label_)
func _run() -> void:
	var battle := (load("res://scenes/FleetBattle3D.tscn") as PackedScene).instantiate()
	root.add_child(battle)
	for i in 5:
		await process_frame
	battle.set_process(false)
	battle.presentation.set_process(false)
	var r: FleetRenderer = battle.presentation.renderer
	var original: BattleSource = r.src
	var f = battle.alive(0)[0]
	var sq := original.squadron(f.id).duplicate(true)
	var core_hash: String = battle.sim.fingerprint()
	var source := PublicSource.new(battle)
	source.public_squadrons[f.id] = sq
	r.src = source
	sq.visual_motion_form = "block"
	sq.layout_heading = 0.0
	sq.heading = 0.0
	sq.aim_heading = 0.0
	sq.slot_sign = 1
	sq.motion_speed = 0.0
	sq.motion_max_speed = 60.0
	sq.motion_contact = false
	var v := r._make_vis(sq)
	var old = r.vis[f.id]
	r.vis[f.id] = v
	check(v.slots.size() > 0, "실제 함대 표시 슬롯 생성")
	for kind in ["block", "line", "column", "echelon", "arc"]:
		var points := r.motion_points(kind, 100)
		var mean := Vector3.ZERO
		var unique := {}
		for p: Vector3 in points:
			mean += p
			unique[p] = true
		check(mean.length() < 0.001 and unique.size() == 100, kind + " 중심·중복 없는 고정 슬롯")
	check(r.motion_points("arc", 1).size() == 1, "한 척 호 진형 유한")
	var before := v.slots.map(func(s): return s.pos)
	sq.visual_motion_form = "line"
	r._reform(v, sq)
	for i in v.slots.size():
		check(v.slots[i].pos == before[i] and v.slots[i].k == i, "진형 명령 현재 위치와 k 보존")
	r._follow(v, sq, 0.25)
	check(v.form_elapsed > 0.0 and v.form_elapsed < 5.0, "5초 전환 진행")
	before = v.slots.map(func(s): return s.pos)
	sq.visual_motion_form = "arc"
	r._reform(v, sq)
	for i in v.slots.size():
		check(v.slots[i].pos == before[i], "전환 중 재명령 순간이동 없음")
	for i in 120:
		r._follow(v, sq, 0.05)
	check(is_equal_approx(v.form_elapsed, 5.0), "5초 전환 완료")
	var dead: FleetRenderer.Slot = v.slots[2]
	r._hide_slot(v, dead)
	var k := dead.k
	sq.visual_motion_form = "column"
	r._reform(v, sq)
	var full_points := r.motion_points("column", v.slots.size())
	for i in 120:
		r._follow(v, sq, 0.05)
	for s: FleetRenderer.Slot in v.slots:
		var p: Vector3 = full_points[s.k]
		check(s.home_to.is_equal_approx(Vector3(p.z, 0.0, -p.x) * source.unit_scale()), "격침 후 전환에도 원래 k 자리")
	check(not v.slots[k].alive and v.slots[k] == dead, "격침 구멍 유지")
	sq.has_move = true
	sq.move_to = sq.pos + Vector2(200.0, 0.0)
	check(r.destination_slots(f.id).size() == v.alive_n, "도착 미리보기 생존 슬롯만")
	sq.motion_speed = 60.0
	check(is_equal_approx(r._slot_scale(sq).z, 1.6), "정본 최고속도에서 이동 늘림1.6")
	battle.logh7_options.stretch = false
	check(is_equal_approx(r._slot_scale(sq).z, 1.0), "이동 늘림 옵션 해제")
	battle.logh7_options.stretch = true
	sq.motion_speed = 0.0
	before = v.slots.map(func(s): return s.pos)
	sq.layout_heading = PI
	sq.heading = PI
	sq.aim_heading = PI
	sq.slot_sign = -1
	for i in 20:
		r._follow(v, sq, 0.05)
	for i in v.slots.size():
		if v.slots[i].alive:
			check(v.slots[i].pos.distance_to(before[i]) < 0.02, "제자리 반전 월드 자리 유지")
			check(absf(angle_difference(v.slots[i].yaw, -TAU)) < 0.002, "1초 함선 반전")
	for key in ["arc", "echelon"]:
		before = v.slots.map(func(s): return s.pos)
		sq.visual_motion_form = key
		r._reform(v, sq)
		var canonical := r.motion_points(key, v.slots.size())
		for s: FleetRenderer.Slot in v.slots:
			check(s.pos == before[s.k], "반전 뒤 새 " + key + " 현재 월드 위치 연속")
			var p: Vector3 = canonical[s.k]
			var expected := Vector3(p.z, 0.0, -p.x) * source.unit_scale()
			check((s.home_to * float(sq.slot_sign)).is_equal_approx(expected), "반전 뒤 " + key + " 원본 정방향 목표")
		for i in 120:
			r._follow(v, sq, 0.05)
	source.public_squadrons[9999] = {"pos": sq.pos + Vector2(200, 120), "contact": "confirmed"}
	sq.motion_contact = true
	sq.contact_id = 9999
	for i in 30:
		r._follow(v, sq, 0.05)
	var target := source.to3(source.public_squadrons[9999].pos)
	for s: FleetRenderer.Slot in v.slots:
		if s.alive:
			var diff := target - s.pos
			check(absf(angle_difference(s.yaw, -atan2(diff.z, diff.x) - PI)) < 0.002, "각 함선 공개 접촉 중심 조준")
	source.public_squadrons.erase(9999)
	sq.motion_contact = false
	sq.aim_heading = sq.layout_heading
	for i in 30:
		r._follow(v, sq, 0.05)
	for s: FleetRenderer.Slot in v.slots:
		if s.alive:
			check(absf(angle_difference(s.yaw, -float(sq.layout_heading) - PI)) < 0.002, "접촉 상실 뒤 배치축 함수 복귀")
	check(battle.sim.fingerprint() == core_hash, "모든 시각 조작 코어 불변")
	sq.recon_ships = 2
	var scouts := r.recon_slots_for(f.id).duplicate()
	check(scouts.size() == 2, "정찰 생존 2 표식")
	var unrelated: FleetRenderer.Slot = null
	for s: FleetRenderer.Slot in v.slots:
		if s.alive and not scouts.has(s.k):
			unrelated = s
			break
	if unrelated:
		var positions := v.slots.map(func(s): return s.pos)
		r._hide_slot(v, unrelated)
		check(r.recon_slots_for(f.id) == scouts, "비정찰 시각 격침은 정찰 고정 k 불변")
		for s: FleetRenderer.Slot in v.slots:
			check(s.pos == positions[s.k], "정찰 표식 정정이 함선 위치를 이동하지 않음")
	r._hide_slot(v, v.slots[scouts[1]])
	check(r.recon_slots_for(f.id).size() == 2, "정본 정찰 손실 없는 연출 격침은 표식 수 유지")
	var surviving_k: int = r.recon_slots_for(f.id)[0]
	sq.recon_ships = 1
	check(r.recon_slots_for(f.id) == [surviving_k], "정찰 2→1 실제 수와 생존 k 유지")
	sq.recon_ships = 0
	check(r.recon_slots_for(f.id).is_empty(), "정찰 1→0 표식 제거")
	for s: FleetRenderer.Slot in v.slots:
		if s.alive and v.alive_n > 1:
			r._hide_slot(v, s)
	check(r.destination_slots(f.id).size() == 1, "한 생존 슬롯 도착 미리보기")
	for s: FleetRenderer.Slot in v.slots:
		if s.alive:
			r._hide_slot(v, s)
	check(r.destination_slots(f.id).is_empty(), "생존 0 슬롯 도착 미리보기 빈값")
	check(is_finite(r.fleet_radius(f.id)), "생존 0 슬롯 윤곽 유한")
	r.vis[f.id] = old
	v.node.queue_free()
	r.src = original
	# 실제 코어 135° 명령: 반전 hold 중 중심뿐 아니라 전체 생존 슬롯도 제자리에 머문다.
	battle.sim.st.ai_timer = 1 << 40
	for core in battle.sim.st.fleets:
		core.pos = battle.FIELD_SIZE - Vector2(70, 70) if core.side == 1 else Vector2(70, 70)
		core.has_move = false
		core.target_id = -1
		core.route.clear()
		core.wait = 9000
	var core: FleetState = battle.sim.st.by_id(f.id)
	core.pos = battle.FIELD_SIZE * 0.25
	core.heading = 0.0
	core.layout_heading = 0.0
	core.layout_ready = true
	core.slot_sign = 1
	core.flip_hold_s = 0.0
	core.motion_contact = false
	core.motion_speed = 0.0
	core.face_set = false
	core.strafe = false
	battle._sync()
	battle.vm.interpolate(1.0)
	r.reset()
	r.update(0.0)
	battle.issue(BattleCommands.make("move", [f.id], -1, core.pos + Vector2.from_angle(deg_to_rad(135.0)) * 220.0, {"logh7": true, "flip": true}))
	battle.update_sim(0.05)
	battle.vm.interpolate(1.0)
	r.update(0.05)
	var actual: FleetRenderer.FleetVis = r.vis[f.id]
	before = actual.slots.map(func(s): return s.pos)
	var fixed_center := core.pos
	check(core.flip_hold_s > 0.0, "실제 135° 반전 hold 진입")
	for i in 15:
		battle.update_sim(0.05)
		battle.vm.interpolate(1.0)
		r.update(0.05)
		check(core.pos == fixed_center and absf(angle_difference(core.layout_heading, PI)) < 0.0001, "135° 반전 hold 중심·배치축 고정")
		for s: FleetRenderer.Slot in actual.slots:
			if s.alive:
				check(s.pos.distance_to(before[s.k]) < 0.0001, "135° 반전 hold 실제 렌더 슬롯 drift 없음")
	var overlay: TacticalOverlay = battle.presentation.hud.overlay
	var screen_origin := battle.w2s(core.pos)
	var arrow_e := overlay.motion_face_arrow({"to": screen_origin, "motion_face": 0.0})
	var arrow_w := overlay.motion_face_arrow({"to": screen_origin, "motion_face": PI})
	check(arrow_e.size() == 4 and arrow_e[1].x > arrow_e[0].x and arrow_w[1].x < arrow_w[0].x, "마우스·터치 motion_face 방향 화살표")
	print("LOGH7_VISUAL_", "PASS" if fails == 0 else "FAIL")
	quit(1 if fails else 0)
