extends SceneTree

var failed := 0
var battle: Node

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, why: String) -> void:
	if not ok:
		failed += 1
		print("FAIL ", why)

func settle() -> void:
	Input.flush_buffered_events()
	await process_frame
	await process_frame

func mouse(point: Vector2, button: int, down: bool, ctrl := false) -> void:
	var e := InputEventMouseButton.new()
	e.position = point
	e.global_position = point
	e.button_index = button
	e.pressed = down
	e.ctrl_pressed = ctrl
	root.push_input(e, true)

func motion(point: Vector2) -> void:
	var e := InputEventMouseMotion.new()
	e.position = point
	e.global_position = point
	root.push_input(e, true)

func key(code: int) -> void:
	var e := InputEventKey.new()
	e.keycode = code
	e.pressed = true
	root.push_input(e, true)

func touch(point: Vector2, down: bool) -> void:
	var e := InputEventScreenTouch.new()
	e.index = 0
	e.position = point
	e.pressed = down
	root.push_input(e, true)

func run() -> void:
	battle = load("res://scenes/FleetBattle3D.tscn").instantiate()
	root.add_child(battle)
	await process_frame
	battle.presentation.hud.begin_battle()
	battle.G.hold = true
	battle.logh7_options.help = false
	battle.presentation.hud.visible = false
	battle.cam_z = 0.7
	battle.cam_pos = battle.field() * 0.5
	await settle()
	var mine: Array = battle.alive(0)
	check(mine.size() >= 4, "실제 적벽 함대 4개 이상")
	if mine.size() < 4:
		quit(1)
		return
	# 편성·수치를 유지하고 입력 검사에 필요한 화면 배치만 분리한다.
	for i in mine.size():
		battle.sim.st.by_id(mine[i].id).pos = Vector2(470 + i * 170, 620)
	battle._sync()
	battle.vm.interpolate(1)
	await settle()
	var mg = battle.motion_groups
	var ids: Array = mine.slice(0, 4).map(func(f): return f.id)
	mg.select_nodes(ids.slice(0, 3))
	mg.group_selection()
	var inner: int = mg.selection()[0]
	mg.select_nodes([inner, ids[3]])
	mg.group_selection()
	var outer: int = mg.selection()[0]
	check(mg.parents.get(inner) == outer and mg.leaves(outer).size() == 4, "중첩 묶음 트리")
	check(mg.norm([outer, inner, ids[0]]) == [outer], "부모·자식 선택 정규화")
	var p0: Vector2 = battle.w2s(mine[0].pos)
	battle.input_node._last_click = -10000
	mouse(p0, MOUSE_BUTTON_LEFT, true)
	mouse(p0, MOUSE_BUTTON_LEFT, false)
	await settle()
	check(mg.selection() == [outer], "실제 왼쪽 클릭은 최상위 묶음")
	mouse(p0, MOUSE_BUTTON_LEFT, true)
	mouse(p0, MOUSE_BUTTON_LEFT, false)
	await settle()
	check(mg.selection() == [ids[0]], "실제 더블클릭은 단일 함대")
	battle.input_node._last_click = -10000
	var p3: Vector2 = battle.w2s(mine[3].pos)
	mouse(p3, MOUSE_BUTTON_LEFT, true, true)
	mouse(p3, MOUSE_BUTTON_LEFT, false, true)
	await settle()
	check(mg.selection() == [outer], "Ctrl 클릭 추가시 조상 선택으로 정규화")
	mg.select_nodes([ids[0]])
	var target := Vector2(760, 700)
	var sp: Vector2 = battle.w2s(target)
	mouse(sp, MOUSE_BUTTON_RIGHT, true)
	motion(sp + Vector2(0, 80))
	mouse(sp + Vector2(0, 80), MOUSE_BUTTON_RIGHT, false)
	await settle()
	var cmd: Dictionary = battle.sim.command_log.back()
	check(cmd.kind == "move" and cmd.args.get("logh7", false), "실제 우드래그 기동 명령 활성화")
	if cmd.kind == "move":
		check((cmd.args.destinations[ids[0]] as Vector2).distance_to(target) < 1.0, "우드래그 시작점이 목적지")
		check(absf(angle_difference(deg_to_rad(cmd.args.facing_deg), PI * 0.5)) < 0.02, "우드래그 끝점은 도착 방향")
	check(not mg.parents.has(ids[0]) and mg.nodes.has(inner), "개별 명령시 안쪽 함대만 이탈")
	mg.select_nodes([ids[1]])
	battle.cmds.order_move(Vector2(650, 720))
	check(not mg.nodes.has(inner) and mg.parents.get(ids[2]) == outer, "1자식 그룹 자동붕괴·상위 구조 유지")
	mg.select_nodes([outer])
	mg.ungroup_selection()
	check(not mg.nodes.has(outer) and not mg.parents.has(ids[3]), "바깥 묶음 해제")
	key(KEY_1)
	await settle()
	check(battle.selected == [mine[0]], "실제 숫자키 함대 단독 선택")
	key(KEY_Q)
	await settle()
	cmd = battle.sim.command_log.back()
	check(cmd.kind == "motion_form" and cmd.args.form == "block", "실제 Q키 대열 모양 명령")
	var form_before: String = battle.sim.st.by_id(ids[0]).formation_id
	key(KEY_T)
	await settle()
	check(battle.sim.st.by_id(ids[0]).formation_id == form_before, "대열 모양은 정본 진형 능력치 유지")
	mouse(p0, MOUSE_BUTTON_RIGHT, true)
	mouse(p0, MOUSE_BUTTON_RIGHT, false)
	await settle()
	check(battle.motion_panel.popup.visible, "실제 아군 우클릭 상황 메뉴")
	battle.motion_panel.hide_menu()
	var log_count: int = battle.sim.command_log.size()
	var bar: Rect2 = battle.motion_panel.bar.get_global_rect()
	mouse(bar.position + Vector2(10, 10), MOUSE_BUTTON_RIGHT, true)
	mouse(bar.position + Vector2(10, 10), MOUSE_BUTTON_RIGHT, false)
	await settle()
	check(battle.sim.command_log.size() == log_count, "HUD 우클릭 전장 명령 누수 없음")
	mg.select_nodes([ids[0]])
	target = Vector2(850, 760)
	sp = battle.w2s(target)
	touch(sp, true)
	touch(sp, false)
	await settle()
	cmd = battle.sim.command_log.back()
	check(cmd.kind == "move" and cmd.args.get("logh7", false) and (cmd.args.destinations[ids[0]] as Vector2).distance_to(target) < 1, "실제 빈 곳 터치탭 이동")
	mg.select_nodes(ids.slice(0, 3))
	mg.group_selection()
	var g: int = mg.selection()[0]
	var a: Vector2 = battle.w2s(mine[0].pos) - Vector2(20, 20)
	var b: Vector2 = battle.w2s(mine[2].pos) + Vector2(20, 20)
	check(mg.box_nodes(a, b) == [g], "상자 전체 포함시 묶음")
	check(mg.box_nodes(p0 - Vector2(10, 10), p0 + Vector2(10, 10)) == [ids[0]], "상자 일부 포함시 개별 함대")
	var old_combat: bool = battle.sim.motion_combat_enabled
	battle.motion_panel.toggle_option("combat")
	check(battle.sim.motion_combat_enabled != old_combat and battle.sim.command_log.back().kind == "motion_options", "교전 옵션 기록·적용")
	battle.motion_panel.toggle_option("combat")
	await extended_cases(mine, ids)
	mg.reset()
	check(mg.nodes.is_empty() and mg.parents.is_empty(), "재시작 그룹 초기화")
	battle.queue_free()
	await process_frame
	print("LOGH7_INPUT_PASS" if failed == 0 else "LOGH7_INPUT_FAIL %d" % failed)
	quit(0 if failed == 0 else 1)

func sync_core() -> void:
	battle._pump()
	battle.vm.interpolate(1.0)

func finish_move(targets: Dictionary, label: String) -> void:
	for tick in 900:
		if targets.keys().all(func(fid): return not battle.sim.st.by_id(fid).has_move):
			break
		battle.sim.step()
	sync_core()
	var tolerance: float = battle.sim.R.arrive_r + 1.0
	for fid in targets:
		var f = battle.sim.st.by_id(fid)
		check(not f.has_move and f.pos.distance_to(targets[fid]) <= tolerance, "%s 함대 %d 실제 도착" % [label, fid])
	var keys: Array = targets.keys()
	if keys.size() > 1:
		var base: int = keys[0]
		for fid in keys.slice(1):
			var relative: Vector2 = battle.sim.st.by_id(fid).pos - battle.sim.st.by_id(base).pos
			check(relative.distance_to(targets[fid] - targets[base]) <= tolerance * 2, "%s 상대 배치 유지" % label)

func extended_cases(mine: Array, ids: Array) -> void:
	var mg = battle.motion_groups
	# 실제 core의 AI/교전을 격리해 입력→중첩 계획→이동/도착을 끝까지 검사한다.
	battle.sim.endless = true
	battle.motion_panel.toggle_option("combat")
	for f in battle.sim.st.fleets:
		f.control = "direct"
		f.has_move = false
		f.retreat_order = false
		if f.side == 1:
			f.dead = true
	for i in ids.size():
		var f = battle.sim.st.by_id(ids[i])
		f.pos = Vector2(600 + i % 2 * 180, 420 + floori(float(i) / 2) * 180)
		f.heading = 0
		f.layout_heading = 0
		f.layout_ready = true
		f.face_set = false
	sync_core()
	mg.reset()
	mg.select_nodes(ids.slice(0, 2))
	mg.group_selection()
	var inner: int = mg.selection()[0]
	mg.select_nodes([inner, ids[2]])
	mg.group_selection()
	var outer: int = mg.selection()[0]
	var before := {}
	for fid in mg.leaves(outer):
		before[fid] = battle.by_id(fid).pos
	key(KEY_B)
	await settle()
	var cmd: Dictionary = battle.sim.command_log.back()
	check(cmd.kind == "move" and cmd.args.get("strafe", false), "실제 B는 짧은 후진 move")
	check(not cmd.args.has("destination_facings"), "후진은 도착 방향을 덮어쓰지 않음")
	for fid in mg.leaves(outer):
		var f = battle.sim.st.by_id(fid)
		check(not f.retreat_order and f.out == "", "B 후진은 전술 퇴각/탈출을 설정하지 않음")
		check((cmd.args.destinations[fid] as Vector2).distance_to(before[fid] - Vector2(220, 0)) < 0.001, "중첩 묶음 후진은 공통 이동벡터")
	finish_move(cmd.args.destinations, "중첩 묶음 후진")
	check(mg.parents.get(inner) == outer, "묶음 후진 후 중첩 유지")
	# 원본의 회전 이동은 실제 core에서도 바깥·안쪽 상대 배치를 유지한다.
	battle.cmds.order_move(Vector2(900, 650), false, 90.0)
	cmd = battle.sim.command_log.back()
	finish_move(cmd.args.destinations, "중첩 묶음 회전 이동")
	mg.select_nodes([outer])
	battle.cmds.motion_form("line")
	cmd = battle.sim.command_log.back()
	check(mg.nodes[outer].form == "line" and mg.nodes[inner].form == "line", "중첩 대열 형상 동기화")
	finish_move(cmd.args.destinations, "중첩 묶음 진형 재배치")
	# 긴 실제 대열 끝의 생존 슬롯으로 클릭/메뉴를 검사한다.
	mg.select_nodes([ids[0]])
	battle.cmds.motion_form("line")
	var renderer = battle.presentation.renderer
	for tick in 420:
		renderer.update(1.0 / 60.0)
	battle.motion_panel._process(0.01)
	check(not battle.motion_panel.pending_forms.has(ids[0]), "대열 전환 완료 감시 해제")
	check(battle.motion_panel.log_items.any(func(item): return "대열 전환 완료" in item.label.text), "대열 전환 완료 로그")
	check("가로줄" in battle.motion_panel.info.text and "정찰함" in battle.motion_panel.info.text, "현재 대열·정찰수 정보")
	var visual = renderer.vis[ids[0]]
	var point := Vector2.ZERO
	var distance_ := 0.0
	for slot in visual.slots:
		if slot.alive:
			var candidate: Vector2 = battle.camera.unproject_position(slot.pos)
			var d: float = candidate.distance_to(battle.w2s(battle.by_id(ids[0]).pos))
			if d > distance_:
				distance_ = d
				point = candidate
	check(distance_ > maxf(28.0, 52.0 * battle.cam_z), "가장자리 슬롯이 기존 중심 히트범위 밖")
	var hit = battle.input_node.hit_fleet(point)
	check(hit != null and hit.id == ids[0], "대열 가장자리 실제 생존 슬롯 히트")
	mg.select_nodes([])
	battle.input_node._last_click = -10000
	mouse(point, MOUSE_BUTTON_LEFT, true)
	mouse(point, MOUSE_BUTTON_LEFT, false)
	await settle()
	check(battle.selected.has(battle.by_id(ids[0])), "끝 함선 실제 클릭 선택")
	mouse(point, MOUSE_BUTTON_RIGHT, true)
	mouse(point, MOUSE_BUTTON_RIGHT, false)
	await settle()
	check(battle.motion_panel.popup.visible and battle.motion_panel.form_buttons.line.button_pressed, "끝 함선 메뉴와 현재 대열 활성 표시")
	battle.motion_panel.hide_menu()
	# 최초 숫자키 매핑은 격침과 새 함대 등장 후에도 바뀌지 않는다.
	var initial: Array = battle.logh7_pick_ids.duplicate()
	battle.sim.st.by_id(initial[0]).dead = true
	sync_core()
	key(KEY_2)
	await settle()
	check(battle.selected.size() == 1 and battle.selected[0].id == initial[1], "첫 함대 격침 뒤 2번키 ID 안정")
	if initial.size() >= 6:
		key(KEY_6)
		await settle()
		check(battle.selected.size() == 1 and battle.selected[0].id == initial[5], "첫 함대 격침 뒤 6번키 유지")
	var reinforcement := FleetState.new()
	reinforcement.id = 90001
	reinforcement.side = 0
	reinforcement.name = "키 안정성 증원"
	reinforcement.ships = 1000
	reinforcement.max_ships = 1000
	reinforcement.pos = Vector2(1500, 900)
	battle.sim.st.fleets.append(reinforcement)
	sync_core()
	key(KEY_2)
	await settle()
	check(battle.logh7_pick_ids == initial and battle.selected[0].id == initial[1], "증원 뒤 초기 숫자키 ID 유지")
