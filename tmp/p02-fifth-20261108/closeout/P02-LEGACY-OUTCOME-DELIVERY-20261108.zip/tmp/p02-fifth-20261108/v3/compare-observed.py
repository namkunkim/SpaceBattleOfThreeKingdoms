from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path.cwd()
V3 = Path(__file__).resolve().parent
OUT = V3.parent
PRODUCT = ("scripts/world/battle_outcome.gd", "scripts/world/auto_resolver.gd")
BEFORE, AFTER = (OUT / name for name in sys.argv[1:3])
BASE = json.loads((OUT / "baseline.json").read_bytes())
COMMON = "product-outcome-common"
CLEAN = "world-link-clean"
RETURNING = "world-link-returning"
WORKER = "p02_worker_adapter"
HEADLESS = "p02_headless_adapter"
BOUNDARY = "product-outcome-boundary"
BASE_SUITES = (COMMON, CLEAN, RETURNING, WORKER, HEADLESS)

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def same_file(path, record):
    return path.stat().st_size == record["bytes"] and sha(path) == record["sha256"]

def one_match(path, regex):
    matches = re.findall(regex, path.read_text(encoding="utf8"), re.M)
    assert len(matches) == 1, (path, regex, matches)
    return matches[0]

for path, record in read(V3 / "oracle-freeze.json").items():
    assert same_file(Path(path), record)
for path, record in read(V3 / "fixed-proof-inputs.json").items():
    assert same_file(Path(path), record)
before_inputs = read(BEFORE / "inputs.json")
after_inputs = read(AFTER / "inputs.json")
assert set(after_inputs) - set(before_inputs) == {"tmp/p02-fifth-20261108/v3/product-outcome-boundary.gd"}
assert set(before_inputs) - set(after_inputs) == set()
assert sorted(p for p in before_inputs if before_inputs[p] != after_inputs[p]) == sorted(PRODUCT)

def run_report(stage, names):
    rows = read(stage / "processes.json")
    assert [r["name"] for r in rows] == list(names)
    for name, row in zip(names, rows):
        dirname = stage / name
        assert row["exit"] == (1 if name == CLEAN else 0) and row["marker"] and not row["script_error"] and not row["timeout"], name
        assert row == read(dirname / "process.json")
        assert row["user_start"] == read(dirname / "user-start.json")
        assert Path(row["user_probe"]["dir"]).resolve() == Path(row["expected_user"]).resolve()
        expected_settings = name == RETURNING
        assert set(row["user_start"]) == ({"settings.cfg"} if expected_settings else set())
        assert row["user_probe"]["initial_files"] == (["settings.cfg"] if expected_settings else [])
        if expected_settings:
            assert row["user_start"]["settings.cfg"] == row["user_end"]["settings.cfg"]
            assert row["user_probe"]["settings_sha"] == row["user_start"]["settings.cfg"]["sha256"]
        for stream in ("stdout", "stderr"):
            assert sha(dirname / stream) == row[stream]
        if "result_sha256" in row:
            data = dirname / ("observations.json" if name == HEADLESS else "result.json")
            assert sha(data) == row["result_sha256"]
        if name in (COMMON, BOUNDARY):
            actual = read(dirname / "result.json")
            assert actual["failures"] == 0
            count, prefix = (18, "A") if name == COMMON else (7, "B")
            assert sorted(actual["rows"]) == [prefix + f"{i:02d}" for i in range(1, count + 1)]
        user = Path(row["expected_user"])
        assert all(same_file(user / p, info) for p, info in row["user_end"].items()), name
    return dict(zip(names, rows))

old_run = run_report(BEFORE, BASE_SUITES)
new_run = run_report(AFTER, BASE_SUITES + (BOUNDARY,))
old = read(V3 / "original-outcome-oracle.json")
new = read(AFTER / COMMON / "result.json")
assert old["rows"] == new["rows"] and old["checks"] == new["checks"]
assert old["guard"]["classes"] == new["guard"]["classes"] == ["res://" + p for p in PRODUCT]
assert old["guard"]["version"] == new["guard"]["version"]
assert old["profile"] == new["profile"]
assert old_run[COMMON]["user_end"]["settings.cfg"] == new_run[COMMON]["user_end"]["settings.cfg"]
assert old["rows"]["A03"]["tick"] == 10 and old["rows"]["A03"]["consumed"]
assert old["rows"]["A06"] == {"ok": False, "error": "unsupported_scenario", "path": "profile"}
assert (BEFORE / HEADLESS / "observations.json").read_bytes() == (AFTER / HEADLESS / "observations.json").read_bytes()
for suite in (WORKER, HEADLESS):
    def normalized_stdout(stage):
        value = (stage / suite / "stdout").read_text(encoding="utf8")
        value = re.sub(r"^FIFTH_USER .*\n", "", value, flags=re.M)
        return re.sub(r"running_frames_observed=\d+", "", value)
    assert normalized_stdout(BEFORE) == normalized_stdout(AFTER)
    assert (BEFORE / suite / "stderr").read_bytes() == (AFTER / suite / "stderr").read_bytes() == b""

def failure_lines(stage):
    value = (stage / CLEAN / "stderr").read_text(encoding="utf8")
    return "\n".join(line for line in value.splitlines() if "TEST_FAIL" in line or "res://tests/world_link.gd" in line)

first = OUT / "before-attempt-01/world_link/stderr"
original_lines = "\n".join(line for line in first.read_text(encoding="utf8").splitlines() if "TEST_FAIL" in line or "res://tests/world_link.gd" in line)
assert original_lines == failure_lines(BEFORE) == failure_lines(AFTER)
diagnostics = {}
for suite in (COMMON, CLEAN, RETURNING):
    old_stderr = (BEFORE / suite / "stderr").read_text(encoding="utf8")
    new_stderr = (AFTER / suite / "stderr").read_text(encoding="utf8")
    old_diagnostics = re.findall(r"(?:WARNING|ERROR): (.*)", old_stderr)
    new_diagnostics = re.findall(r"(?:WARNING|ERROR): (.*)", new_stderr)
    assert re.sub(r"\d+(?= ObjectDB instances| resources still in use)", "<count>", old_stderr) == re.sub(r"\d+(?= ObjectDB instances| resources still in use)", "<count>", new_stderr)
    diagnostics[suite] = {"before": old_diagnostics, "after": new_diagnostics,
                          "stderr_identical": old_stderr == new_stderr}

boundary = read(AFTER / BOUNDARY / "result.json")
assert all(boundary["rows"][key]["joined"] and boundary["rows"][key]["worker_caller"] != boundary["rows"][key]["main_caller"] for key in ("B01", "B02", "B03"))
assert boundary["rows"]["B04"] == {"ready": True, "joined": True, "poll": False, "unpublished": True}
assert boundary["rows"]["B05"]["repeat"]
workspace = read(OUT / (AFTER.name + "-workspace.json"))
assert set(workspace["drift"]) == set(PRODUCT), workspace["drift"]
external_start = read(V3 / "external-start.json")
external_end = read(V3 / "external-end.json")
assert external_start["baseline_count"] == external_end["baseline_count"] == 12281
assert external_start["owned_drift"] == external_end["owned_drift"]
assert set(external_end["owned_drift"]) == set(PRODUCT)
assert set(workspace["new"]) <= set(external_end["files"])
assert not set(after_inputs).intersection(external_end["files"])
assert not external_end["comparison"]["changed_or_removed"]
assert not external_end["removed_during_read"] and not external_end["arrived_during_read"]
for path, info in external_end["files"].items():
    assert same_file(ROOT / path, info), path
for product in PRODUCT:
    assert sha(OUT / (Path(product).name + ".before.txt")) == BASE["paths"][product]["sha256"]
    assert sha(ROOT / product) == after_inputs[product]["sha256"]
    original = (OUT / (Path(product).name + ".before.txt")).read_bytes()
    current = (ROOT / product).read_bytes()
    if product.endswith("battle_outcome.gd"):
        start, end = b"static func from_sim(", b"static func _loss("
    else:
        start, end = b"\t_thread = Thread.new()", b"func cancel()"
    restored = current[:current.index(start)] + original[original.index(start):original.index(end)] + current[current.index(end):]
    assert restored == original
    diff = subprocess.run(["git", "diff", "--no-index", "--", str(OUT / (Path(product).name + ".before.txt")), product], capture_output=True)
    assert diff.returncode == 1
    (V3 / (Path(product).name + ".owned.diff")).write_bytes(diff.stdout)
check = subprocess.run(["git", "diff", "--check", "--", *PRODUCT], capture_output=True, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"})
(V3 / "owned-diff-check.stdout").write_bytes(check.stdout)
(V3 / "owned-diff-check.stderr").write_bytes(check.stderr)
assert check.returncode == 0
report = {"before": BEFORE.name, "after": AFTER.name, "same_common_rows": len(old["rows"]), "common_checks_per_stage": old["checks"],
          "boundary_rows": len(boundary["rows"]), "boundary_checks": boundary["checks"], "execution_input_count": len(before_inputs),
          "world_link": {"returning": "WORLD_LINK_PASS; suite has no emitted assertion count",
                         "clean": "WORLD_LINK_FAIL 1; known prologue/brief diagnostic preserved, excluded from pass count"},
          "worker_checks": int(one_match(AFTER / WORKER / "stdout", r"^P02_WORKER_CHECKS (\d+)")),
          "headless_counts": one_match(AFTER / HEADLESS / "stdout", r"cases=(\d+) checks=(\d+) rejections=(\d+) natural=(\d+) timeout=(\d+)"),
          "input_differences": list(PRODUCT), "processes": {"before": old_run, "after": new_run}, "workspace": workspace,
          "diagnostics": diagnostics, "external_observation": {
              "review_sha256": sha(OUT / "REVIEW-CONCURRENT-FILES-INDEPENDENT.md"),
              "start_sha256": sha(V3 / "external-start.json"), "end_sha256": sha(V3 / "external-end.json"),
              "files": external_end["observed_files"], "ownership": "unverified", "overlap_with_inputs": 0,
              "changed_or_removed_between_observations": 0, "historical_bytes_claimed": False}}
(V3 / "gate-verdict.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf8")
print("PASS", report["same_common_rows"], report["boundary_rows"], report["common_checks_per_stage"], report["boundary_checks"])
