from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib, json, os, re, subprocess, sys

root = Path.cwd()
evidence = root / "tmp/p02-fourth-20261108"
engine = Path("C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe")
cache = root / ".godot/global_script_class_cache.cfg"
fixture = root / "tests/fixtures/p02"
owner = "core/battle/operation_private_state.gd"
runner = "tests/p02_viewer_events.gd"
baseline = json.loads((evidence / "baseline.json").read_bytes())
regressions = ("p02_headless_adapter", "p02_worker_adapter", "p02_replay_adapter", "detection_rules",
               "battle_flow", "placement", "world_link", "i01b_active_replace")

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf8")

def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"})

def audit(label):
    def check(row):
        path = root / row["path"]
        try:
            size = path.stat().st_size
            found = sha(path)
            if size == row["bytes"] and found == row["sha256"]:
                return None
            return {"path": row["path"], "sha": found, "expected": row["sha256"], "bytes": size}
        except FileNotFoundError:
            return {"path": row["path"], "missing": True}
    with ThreadPoolExecutor(12) as pool:
        changes = [item for item in pool.map(check, baseline["rows"]) if item]
    tracked = git("ls-files", "-z").decode().split("\0")
    untracked = git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0")
    live = {p for p in tracked + untracked if p and not p.startswith("tmp/p02-fourth-20261108/")}
    branch_head_index = (git("branch", "--show-current").decode().strip() == baseline["branch"]
                         and git("rev-parse", "HEAD").decode().strip() == baseline["head"]
                         and git("ls-files", "-s", "-z") == (evidence / "index.raw").read_bytes()
                         and sha(root / ".git/index") == baseline["index_file_sha256"])
    result = {"checked": len(baseline["rows"]), "changes": changes,
              "new": sorted(live - {r["path"] for r in baseline["rows"]}),
              "branch_head_index_match": branch_head_index}
    dump(evidence / (label + "-audit.json"), result)
    return result

def runtime():
    for row in json.loads((evidence / "runtime-freeze.json").read_bytes()):
        assert sha(row["Path"]) == row["Hash"].lower(), row["Path"]

def main(stage):
    runtime()
    out = evidence / stage
    out.mkdir()
    jobs = []
    def job(label, script, args=(), expected=None, output=None):
        cmd = [str(engine), "--headless", "--path", str(root), "--log-file",
               str(out / (label + ".engine.log")), "-s", str(script)]
        if args:
            cmd += ["--", *map(str, args)]
        jobs.append((label, cmd, expected, output))
    def cli(label, option, input, expected=None):
        output = out / (label + ".json")
        job(label, "tests/autoresolve.gd", (option, input, "--out", output), expected, output)
    if stage not in ("baseline-regressions", "baseline-world"):
        cli("sync", "--operation-input", fixture / "poc.json")
        cli("worker", "--operation-worker", fixture / "worker-services.json")
        cli("replay", "--operation-replay", fixture / "replay-commands.json")
        cli("unsupported", "--operation-input", evidence / "unsupported.json",
            {"ok": False, "error": "unsupported_input_representation", "path": "definition"})
    if stage == "baseline-world":
        job("world_link", root / "tests/world_link.gd")
    elif stage != "before":
        for script in regressions:
            path = root / "tests" / (script + ".gd")
            if script == "p02_headless_adapter":
                raw = path.read_bytes()
                old = b"res://tmp/p02-first-integration-20261105/attempt1-observations.json"
                assert raw.count(old) == 1
                path = out / "headless-output-relocation.gd"
                new = "res://" + (out / "headless-observation.json").relative_to(root).as_posix()
                path.write_bytes(raw.replace(old, new.encode()))
            job(script, path)
        if stage not in ("baseline-regressions", "baseline-world"):
            job("viewer", runner)
    paths = {engine, cache, root / ".godot/uid_cache.bin", root / "project.godot", Path(__file__).resolve()}
    paths.update(root / r["path"] for r in baseline["rows"] if r["path"].endswith((".gd", ".tscn", ".tres"))
                 and not r["path"].startswith(("tmp/", "output/")))
    paths.update(root / p for p in re.findall(r'"res://([^"]+\.gd)"', cache.read_text(encoding="utf8")))
    paths.update(fixture.glob("*.json"))
    paths.update((evidence / n) for n in ("unsupported.json", "typed-native.gd", "native-contract.json"))
    if (out / "headless-output-relocation.gd").exists():
        paths.add(out / "headless-output-relocation.gd")
    if stage not in ("before", "baseline-regressions", "baseline-world"):
        paths.add(root / runner)
    paths = sorted(p for p in paths if p.is_file())
    frozen = {str(p): sha(p) for p in paths}
    dump(out / "freeze.json", {"files": frozen, "jobs": [[a, b, c, str(d) if d else None] for a, b, c, d in jobs],
        "version": (evidence / "engine-version.txt").read_text().strip()})

    def run(job_entry):
        label, cmd, expected, output = job_entry
        assert output is None or not output.exists()
        try:
            process = subprocess.run(cmd, cwd=root, capture_output=True, timeout=240 if label == "world_link" else 90)
            stdout, stderr, code, timeout = process.stdout, process.stderr, process.returncode, False
        except subprocess.TimeoutExpired as exc:
            stdout, stderr, code, timeout = exc.stdout or b"", exc.stderr or b"", None, True
        (out / (label + ".stdout")).write_bytes(stdout)
        (out / (label + ".stderr")).write_bytes(stderr)
        lines = (stdout + b"\n" + stderr).splitlines()
        diagnostics = {flag: sum(line.startswith(flag.encode() + b":") for line in lines)
                       for flag in ("SCRIPT ERROR", "ERROR", "WARNING")}
        rejects = [json.loads(line.removeprefix(b"OPERATION_REJECT ")) for line in lines
                   if line.startswith(b"OPERATION_REJECT ")]
        output_sha = sha(output) if output and output.exists() else None
        passed = not timeout and diagnostics["SCRIPT ERROR"] == 0
        if expected is not None:
            passed &= code == 1 and rejects == [expected] and output_sha is None
        else:
            passed &= code == 0 and not rejects and (output is None or output_sha is not None)
        if label not in regressions:
            passed &= diagnostics["ERROR"] == diagnostics["WARNING"] == 0
        return {"label": label, "exit": code, "timeout": timeout, "diagnostics": diagnostics,
                "rejects": rejects, "output_sha256": output_sha, "pass_process": passed}

    with ThreadPoolExecutor(2) as pool:
        results = list(pool.map(run, jobs))
    after_changes = [path for path, value in frozen.items() if sha(path) != value]
    runtime()
    dump(out / "results.json", {"processes": len(results), "cases": results, "freeze_changes": after_changes})
    print(stage, [(r["label"], r["exit"], r["diagnostics"], r["pass_process"]) for r in results], after_changes)

if __name__ == "__main__":
    if sys.argv[1] == "audit":
        print(audit(sys.argv[2]))
    else:
        main(sys.argv[1])


