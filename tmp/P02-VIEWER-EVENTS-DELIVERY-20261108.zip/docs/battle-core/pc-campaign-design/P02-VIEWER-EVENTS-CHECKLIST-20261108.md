# P02 표시용 사건 회수 체크리스트

2026-11-08 KST. 제한 private owner 선행조건의 독립 구현 재심 한정 수용. 전체 P02/I01/I01b/A04~A06 **NOT_READY**, 외부 save schema **UNCLASSIFIED**.

- [x] owner 가드와 exact int 0/1 검증, 오류 시 큐 보존, native 필터와 단일 큐 소진, 반환 typed 깊은 사본을 확인했다. 한 스레드 직렬 호출 계약이며 raw drain과 observe가 있어 보안 권한 경계로 사용할 수 없다.
- [x] 직접 native 오라클로 14행·148개 단언을 확인했다. contact 시점·진영 조건과 자연 발생 salvo/상대 ID 마스킹을 관측했다. raw/side 교환 반례가 실패했다.
- [x] 기본 17개 프로세스를 검증했다. 최초 오염 기준선 및 종합 판정을 보존하고 새 격리 회귀 14개·탐침 3개를 별도로 실행했다. 이전 원경로 i01b 쓰기, WorldLink timeout 및 기존 진단, BattleFlow 전후 역사 차이를 기록했다.
- [x] 격리 입력·출력과 동결 stage 전수 검사, 기존 오염 삽입·새 before 누락 거부를 확인하고 비-Astra 독립 재심에서 한정 수용했다. [결과](P02-VIEWER-EVENTS-RESULT-20261108.md) · [독립 재심](../../../tmp/p02-fourth-20261108/REVIEW-5B-REBASELINE-INDEPENDENT.md)
- [ ] 문서와 전달 ZIP의 독립 마감 판정. 이 항목은 전달물 생성 시점의 상태다.
- [ ] 제품 FleetBattle3D·WorldMap·replay, K01~08 공동 인수와 외부 schema. [P02 진행표](P02-PROGRESS-CHECKLIST.md)
