# P02 첫 실제 headless opt-in — 제한 수용 결과

2026-11-07 KST. 실제 CLI 소비자 연결 한 조각을 구현·검사하고 [다른 모델 최종5b](../../../tmp/p02-first-integration-20261105/REVIEW-5B-ACCEPT-20261107.md)의 **제한 수용**을 받았다. 전체 P02/I01/I01b/A04~A06는 NOT_READY, 외부 save schema는 UNCLASSIFIED다. [전용 체크리스트](P02-FIRST-HEADLESS-CHECKLIST-20261107.md)와 [최신 인계](SESSION-HANDOFF-P02-FIRST-HEADLESS-20261107.md)를 함께 따른다.

## 구현과 실제 연결

`core/battle/operation_runtime_adapter.gd`는 파일·UI·스레드를 모르는 static factory다. 정확한 mode/format/필드·컨테이너·정수 범위·controls·policy를 검증하고 JSON 정수 의미만 한 번 정규화한 뒤 완성된 private owner 하나를 반환한다. 순수 정규화 결과와 factory 성공 metadata를 구분하며 raw sim이나 normalized profile을 성공 metadata에 노출하지 않는다. 기존 exact context/restore 계약을 완화하지 않는다.

`OperationPrivateState.read_projection(side)`와 `summary()`는 guard 및 side 타입·범위 검증을 거친 깊은 사본이다. 실제 `tests/autoresolve.gd`의 `_run`에서 **`--operation-input`이 있을 때만** 입력 파일→factory→공개 side0 정책→queue→advance→ordered drain→결과로 연결한다. opt-in 없는 legacy parser/play/play_rc/정책/통계 본문은 사전 원문 바이트를 보존했다. owner는 정상·반환형 실패 모두 close한 뒤 출력 단계로 이동한다.

CLI는 이번 첫 실제 소비자를 검증하는 기존 실행기이며 제품에 새 CLI가 필수라는 정책이 아니다. FleetBattle3D의 표시/시계/선택/카메라/trace와 AutoResolver의 worker/progress/완료 공개, BattleSim.replay는 아직 연결하지 않았다. 책임·현재 라인·최소 실패 반례는 [수용 계획](../../../tmp/p02-first-integration-20261105/PLAN.md)에 있다.

## opt-in 계약과 사용

```powershell
C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe --headless --path C:\WorkSpace\SpaceBattleOfThreeKingdoms -s tests/autoresolve.gd -- --operation-input res://tests/fixtures/p02/poc.json --out res://tmp/p02-my-new-result.json
```

`--out`은 존재하지 않는 새 파일 경로가 필수다. 동일 예제를 재실행하려면 다른 새 출력 경로를 선택한다. 입력은 `mode="operation"`, `format="p02/restricted-headless/1"`과 명시 profile/seed/hz/initial_controls/policy/max_ticks의 정확 필드다. seed는 uint32, hz10, max_ticks 및 해당 fleet/composition 정수는 signed32 안전 상한을 검사한다. bool·비유한·분수·범위초과·합계 overflow는 변환 전 거부한다. 이 기술 상한은 제품 편성 규모의 실용성 보증이 아니다.

예시 [POC](../../../tests/fixtures/p02/poc.json), [Salvo/Detection/Supply](../../../tests/fixtures/p02/services.json), [원거리 timeout](../../../tests/fixtures/p02/timeout-poc.json)은 작성 시점부터 제한 구성·reinf=[]를 명시한 runtime-ready 입력이다. [출처](../../../tmp/p02-first-integration-20261105/FIXTURE-PROVENANCE.md)를 따른다. stock POC나 실제 적벽에서 모듈/증원을 런타임에 지우지 않고, 지원 밖 입력은 명시 실패하며 legacy fallback이 없다. I01a definition이나 checkpoint도 지원하지 않는다. source→effective 공간 변환은 없고 identity/no-transform이며 전체 I01/K02 충족이 아니다.

none은 즉시 빈 명령을 반환한다. attack5는 공개 full squadron과 confirmed/estimated 접촉만 copied 정책뷰로 소비하고 lost는 제외한다. 현재 Detection.foes가 dead를 매 조회 제외한다는 계약에 한정해 접촉의 정책뷰에 dead=false를 보완한다. 공개 DTO/저장값을 바꾸거나 비공개 체력·좌표를 읽지 않는다. 기존 5초 주기·입력 순서·strict-less tie·attack/missile/fighter 순서를 유지한다. charge30/unknown policy는 선행 거부한다.

기존 output은 열지 않고, write 직전 재검사·flush/get_error·재읽기 바이트 크기/SHA를 확인한 뒤에만 PASS/exit0을 게시한다. 실패한 새 partial 파일은 보존하며 자동 삭제/덮어쓰기 재시도가 없다. OS check-open 경합이나 디스크 장애의 원자 복구는 보장하지 않는다.

## 실행과 독립 검토

새 단계는 **3/K6**이며 과거 P2c5/K6·활성교체2/K6와 별도다. attempt1은 실제 exit1/dead 접근 SCRIPT ERROR8112/timeout assertion1, attempt2는 실제 exit1/SCRIPT ERROR0/typed drain 대 untyped aggregate oracle assertion2로 실패 이력을 보존했다. [반례 보완 계획](../../../tmp/p02-first-integration-20261105/PLAN-ATTEMPT1-REVISION.md)과 [독립 수용](../../../tmp/p02-first-integration-20261105/REVIEW-PLAN-ATTEMPT1-ACCEPT.md) 후 정책·독립 oracle을 보완했고, attempt2는 엄격 타입 비교를 유지한 기대 집계 표현만 수정했다.

| 별도 분모 | 정본 attempt3 관측 |
|---|---|
| API runner | actual exit0, 정상matrix8·13417체크·APInegative32 |
| 정책 의미/timeout | 수제 정답과 생산/독립 reference P9, 별도 T2 모두 일치 |
| 실제 CLI | 명명 거부14 각각 exit1/expected error·path, 정상2 exit0 |
| legacy | 원문 복사/변경후1쌍, 두 프로세스 exit0·출력 JSON 바이트 동일 |
| 최소 회귀 | private70/11553/45·core actual exit0 |

API32+CLI14=고유 명명 거부46이다. CLI는17논리항목/18실제프로세스이며 API runner1·회귀2와 구분한다. 합계21개 프로세스의 원문 captured/engine 로그 SHA와 actual exit를 독립 대조했고 SCRIPT ERROR/ERROR0이다. 신규 정상8의 natural7/timeout1은 결과 관측이다. 조기 종료 POC attack5 두 경우에는5/10/15tick 체크포인트가 없고 나머지6개만 각3개를 갖는다. POC seed0 attack5 종료 tick2/clock150과 services seed0 attack5 tick621/clock62050을 tick×100으로 다시 만들지 않는다.

정책 oracle은 생산 helper와 별도 명령을 생성해 raw BattleSim에 넣고 실제 script property·시계·controls·명령/사건 순서를 비교한다. 입력/조회 alias·읽기 실패·명령 거부 원자성·다음 정상 호출·event1회 drain·close module.sim 해제도 확인했다. Services CLI 사건은 contact/salvo/ship_lost와 종료이며 **supply 완료 사건 E2E는 이번에 관측하지 않았다**. 보급 전체 흐름 완료로 확대하지 않는다.

실제 모델 메타는 같은 parent의 구현 `/root/implementation` gpt-6.1-sol과 구현 비참여 `/root/independent_review` gpt-6-astra를 구분한다. [메타 원출처](../../../tmp/p02-first-integration-20261105/model-independence-evidence.json)는 session/parent/agent_path/turn_context만 기록한다. appendable 원 JSONL의 관측 SHA를 영구 파일 SHA로 취급하지 않는다.

## 편차·보존·마감 근거

--no-chain/--no-m9/--wind 혼합은 계획의 conflicting_option 대신 unknown_option으로 거부되는 **비차단 분류 편차**를 공개한 코드로 수용했다. 어느 경우에도 exit1·fallback/owner 생성/출력쓰기가 없다. 이3경로를 실제 CLI14에 포함했다고 세지 않으며 추가 수정·검사 반복을 하지 않았다. write/flush/verify 실패 분기는 source 검토만 했고 디스크 fault injection은 미실행이다. 실제 I/O 반례는 sentinel 보존·없는 부모·Windows bad*.json open 실패다.

기존 dirty/untracked3960은 과거3879/3660과 다른 분모다. clean tracked였던 autoresolve는 별도 사전 원문으로 동결했다. source35·격리77·정본 cache·HTML·기존 검사·과거 ZIP2를 보존한다. 최종 허용 변경/상위 문서 hunk·현재 SHA는 [최종 감사](../../../tmp/p02-first-integration-20261105/final-delivery-audit.json), payload는 [manifest](../../../tmp/p02-first-integration-20261105/record-manifest.json), 새 압축은 [P02 ZIP](../../../tmp/p02-first-headless-delivery-20261107.zip), CRC/entry/SHA는 [외부 압축 검증](../../../tmp/p02-first-integration-20261105/archive-verification.json)을 따른다. 독립 마감 판정은 [별도 closeout](../../../tmp/p02-first-integration-20261105/REVIEW-CLOSEOUT-20261107.md)이 정본이며 이 결과 문서의 자체 채점으로 대체하지 않는다.

전체 git diff --check는 보존한 기존 상위 P2c행 CRLF/trailing로 actual exit2이며 전체 gate PASS가 아니다. 새 소유 코드 공백은0이다. data_rules를 이번에 재실행하거나 기존 ObjectDB/resources/TRACE 진단을 해소하지 않았다. 원본 branch/HEAD/index를 유지했고 HTML/브라우저/localStorage/editor import·새 worktree·커밋·푸시·병합을 하지 않았다. 과거 ZIP에 최신 문서/코드를 소급 포함하지 않는다.

남은 P02는 실제 UI host/worker/replay 연결과 소비자 사이 I01/K01~08 전체 입력·초기화·실패 공동 인수다. P03~P09, 전체 C0/Cn/ST·global cursor·외부 save/재개/호환·제품 공간·화면/Android·성능·사람플레이는 미완료다.
