extends SceneTree

const Private := preload("res://core/battle/operation_private_state.gd")
const SimScript := preload("res://core/battle/battle_sim.gd")
const TICK := 2
const CONTROLS := ["direct", "direct"]
const NAMES := [
	"correct_pending_and_suffix",
	"duplicate_pending_in_suffix",
	"reordered_or_omitted_suffix",
	"consumer_outlives_restore",
]

var case_name: String
var ids: Array[String] = []
var failed := false
var correct_log: Array
var correct_events: Array

func _initialize() -> void:
	call_deferred("_run")

func _begin(index: int) -> void:
	case_name = NAMES[index]
	print("CASE_START ", case_name)

func _check(number: int, conditions: Dictionary) -> void:
	var id := "%s:%d" % [case_name, number]
	ids.append(id)
	var bad: Array = []
	for key in conditions:
		if not conditions[key]:
			bad.append(key)
	if bad.is_empty():
		print("CHECK ", id, " PASS")
	else:
		failed = true
		print("CHECK ", id, " FAIL ", bad)

func _end() -> void:
	print("CASE_END ", case_name)
func _exact(a: Variant, b: Variant) -> bool:
	if typeof(a) != typeof(b): return false
	if a is Dictionary:
		if not _exact(_dict_type(a), _dict_type(b)) or not _exact(a.keys(), b.keys()): return false
		for key in a:
			if not _exact(a[key], b[key]): return false
		return true
	if a is Array:
		if a.get_typed_builtin() != b.get_typed_builtin() or a.get_typed_class_name() != b.get_typed_class_name(): return false
		if not is_same(a.get_typed_script(), b.get_typed_script()) or a.size() != b.size(): return false
		for i in a.size():
			if not _exact(a[i], b[i]): return false
		return true
	if a is Object: return is_same(a, b)
	return a == b

func _dict_type(value: Dictionary) -> Array:
	return [value.get_typed_key_builtin(), value.get_typed_key_class_name(), value.get_typed_key_script(),
		value.get_typed_value_builtin(), value.get_typed_value_class_name(), value.get_typed_value_script()]

func _profile() -> Dictionary:
	var rules: Dictionary = PocSetup.profile().rules
	rules.world_w = 3400
	rules.world_h = 2300
	var note_array: Array[int] = [7]
	return {"profile_id": "p03-command-suffix", "rules": rules,
		"ally": [{"name": "A", "role": "A", "ships": 30, "lv": 1, "x": 500, "y": 500, "p": 0, "flag": true}],
		"foe": [{"name": "B", "role": "B", "ships": 30, "lv": 1, "x": 2600, "y": 1500, "p": 0, "flag": true}],
		"reinf": [], "note": {"typed_probe": note_array, "key_probe": {7: "value"}, "order_probe": {"first": 1, "last": 2}}}

func _command(label: String, applied := false) -> Dictionary:
	var ids: Array[int] = [999 if label == "R" else 1]
	var point := Vector2(900, 500) if label == "Q" else Vector2(1100, 500) if label == "B" else Vector2.ZERO
	var input_tick: int = {"Q": 77, "S": -1, "I": 88, "B": 89, "R": -1}[label]
	return {"tick": TICK if applied else input_tick, "side": 0, "ids": ids,
		"kind": "move" if label in ["Q", "B"] else "stop", "target_id": -1, "point": point, "args": {}}

func _commands(labels: Array, applied: bool) -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for label in labels: out.append(_command(label, applied))
	return out


func _owner() -> OperationPrivateState:
	var result := Private.create(_profile(), 7, 10, CONTROLS)
	return result.get("owner")

func _closed(owner: OperationPrivateState) -> bool:
	owner.close()
	return _exact(owner.summary(), {"ok": false, "error": "unprepared_owner", "path": "owner"})

func _raw_prefix() -> BattleSim:
	var raw := SimScript.new(7, 10, _profile())
	for fleet in raw.st.fleets:
		fleet.control = "direct"
	for index in TICK:
		raw.step()
	raw.drain_events()
	raw.queue(_command("Q"))
	raw.queue(_command("S"))
	raw.issue(_command("I"))
	return raw

func _release_raw(raw: BattleSim) -> void:
	for field in ["salvo", "detect", "supply"]:
		var module: Variant = raw.get(field)
		if module != null:
			module.sim = null

func _packet(owner: OperationPrivateState) -> Dictionary:
	return owner.capture_completed().get("packet", {})

func _view(packet: Dictionary) -> Dictionary:
	return packet.get("view", {}).get("sim", {})

func _timeline(packet: Dictionary, raw: BattleSim) -> bool:
	var state: Dictionary = packet.get("view", {}).get("state", {})
	return _exact(state.get("tick"), raw.st.tick) and _exact(state.get("clock_ms"), raw.st.clock_ms)

func _fleet_fields(fleet: Variant) -> Array:
	var fields: Array = []
	for key in ["id", "control", "pos", "heading", "has_move", "move_to", "target_id", "moving", "speed"]:
		fields.append(fleet.get(key))
	return fields

func _fleet_parity(packet: Dictionary, raw: BattleSim) -> bool:
	var fields: Array = packet.get("view", {}).get("fleets", [])
	if fields.size() != raw.st.fleets.size():
		return false
	for index in fields.size():
		if not _exact(_fleet_fields(fields[index]), _fleet_fields(raw.st.fleets[index])):
			return false
	return true

func _event_order(events: Array) -> Array:
	var values: Array = []
	for event in events:
		if event.kind == "say":
			values.append(event.value)
		elif event.kind == "rejected":
			values.append(event.value if event.value == "no_selection" else ["rejected", event.value])
	return values

func _drain_ok(result: Dictionary) -> bool:
	return result.get("ok") == true and result.get("events") is Array

func _empty_drain(owner: OperationPrivateState) -> bool:
	var result := owner.drain_events()
	return _drain_ok(result) and result.events.is_empty()

func _restore(owner: OperationPrivateState, packet: Dictionary) -> bool:
	return _exact(owner.restore_completed(packet), {"ok": true}) and _exact(_packet(owner), packet)

func _correct(owner: OperationPrivateState, packet: Dictionary, prefix_ok: bool) -> void:
	_begin(0)
	var raw := _raw_prefix()
	var view := _view(packet)
	_check(1, {"real prefix": prefix_ok, "tick2": raw.st.tick == TICK, "capture timeline": _timeline(packet, raw)})
	_check(2, {
		"log": _exact(view.get("command_log"), _commands(["I"], true)) and _exact(view.get("command_log"), raw.command_log),
		"pending": _exact(view.get("_queue"), _commands(["Q", "S"], false)) and _exact(view.get("_queue"), raw._queue),
		"events": _event_order(view.get("_events", [])) == ["stop"] and _exact(view.get("_events"), raw._events),
	})
	var invalid := _command("R")
	invalid.kind = "unsupported_for_probe"
	_check(3, {"exact unsupported command": _exact(owner.queue(invalid), {"ok": false, "error": "unsupported_command"}), "unchanged packet": _exact(_packet(owner), packet)})
	var accepted := owner.queue(_command("R"))
	raw.queue(_command("R"))
	var queued := _view(_packet(owner))
	_check(4, {
		"accepted": _exact(accepted, {"ok": true}),
		"pending": _exact(queued.get("_queue"), _commands(["Q", "S", "R"], false)),
		"log": _exact(queued.get("command_log"), view.get("command_log")),
		"events": _exact(queued.get("_events"), view.get("_events")),
	})
	var advanced := owner.advance()
	raw.step()
	var finished := _packet(owner)
	var post := _view(finished)
	correct_log = post.get("command_log", [])
	_check(5, {
		"advance": _exact(advanced, {"ok": true}), "empty queue": post.get("_queue") is Array and post._queue.is_empty(),
		"applied log": _exact(correct_log, _commands(["I", "Q", "S", "R"], true)) and _exact(correct_log, raw.command_log),
	})
	_check(6, {"tick/clock": _timeline(finished, raw), "fleet fields": _fleet_parity(finished, raw)})
	var drain := owner.drain_events()
	correct_events = drain.get("events", [])
	_check(7, {"drained": _drain_ok(drain), "raw payload": _exact(correct_events, raw.drain_events()),
		"command events": _event_order(correct_events) == ["stop", "move", "stop", "no_selection"]})
	_check(8, {"empty redrain": _empty_drain(owner), "closed": _closed(owner)})
	_release_raw(raw)
	_end()

func _duplicate(owner: OperationPrivateState, packet: Dictionary) -> void:
	_begin(1)
	var raw := _raw_prefix()
	_check(1, {"exact P restore": _restore(owner, packet)})
	_check(2, {"duplicate Q accepted": _exact(owner.queue(_command("Q")), {"ok": true})})
	raw.queue(_command("Q"))
	var accepted := owner.queue(_command("R"))
	raw.queue(_command("R"))
	var queued := _view(_packet(owner))
	var view := _view(packet)
	_check(3, {
		"R accepted": _exact(accepted, {"ok": true}), "pending": _exact(queued.get("_queue"), _commands(["Q", "S", "Q", "R"], false)),
		"log": _exact(queued.get("command_log"), view.get("command_log")), "events": _exact(queued.get("_events"), view.get("_events")),
	})
	var advanced := owner.advance()
	raw.step()
	var finished := _packet(owner)
	var post := _view(finished)
	var log_rows: Array = post.get("command_log", [])
	_check(4, {"advance": _exact(advanced, {"ok": true}), "empty queue": post.get("_queue") is Array and post._queue.is_empty()})
	_check(5, {
		"log": _exact(log_rows, _commands(["I", "Q", "S", "Q", "R"], true)) and _exact(log_rows, raw.command_log),
		"both Q equal": log_rows.size() == 5 and _exact(log_rows[1], log_rows[3]),
	})
	_check(6, {"tick/clock": _timeline(finished, raw), "fleet fields": _fleet_parity(finished, raw)})
	var drain := owner.drain_events()
	var events: Array = drain.get("events", [])
	_check(7, {"drained": _drain_ok(drain), "raw payload": _exact(events, raw.drain_events()),
		"command events": _event_order(events) == ["stop", "move", "stop", "move", "no_selection"]})
	_check(8, {"log differs": not _exact(log_rows, correct_log), "events differ": not _exact(events, correct_events),
		"empty redrain": _empty_drain(owner), "closed": _closed(owner)})
	_release_raw(raw)
	_end()

func _reordered(packet: Dictionary) -> void:
	_begin(2)
	var suffixes := [["S", "R"], ["R", "S"], ["S"]]
	var keys := ["normal", "reordered", "omitted"]
	var expected_events := [
		["stop", "move", "stop", "stop", "no_selection"],
		["stop", "move", "stop", "no_selection", "stop"],
		["stop", "move", "stop", "stop"],
	]
	var restored := {}
	var queued := {}
	var advanced := {}
	var log_checks: Array[Dictionary] = []
	var drained := {}
	var closed := {}
	for index in keys.size():
		var key: String = keys[index]
		var owner := _owner()
		var raw := _raw_prefix()
		if owner == null:
			restored[key + " create"] = false
			log_checks.append({key + " owner": false})
			_release_raw(raw)
			continue
		restored[key] = _restore(owner, packet)
		var accepted := true
		for label in suffixes[index]:
			accepted = _exact(owner.queue(_command(label)), {"ok": true}) and accepted
		match index:
			0:
				raw.queue(_command("S"))
				raw.queue(_command("R"))
			1:
				raw.queue(_command("R"))
				raw.queue(_command("S"))
			2:
				raw.queue(_command("S"))
		queued[key + " accepted"] = accepted
		queued[key + " pending"] = _exact(_view(_packet(owner)).get("_queue"), _commands(["Q", "S"] + suffixes[index], false))
		advanced[key + " advance"] = _exact(owner.advance(), {"ok": true})
		raw.step()
		var finished := _packet(owner)
		var view := _view(finished)
		advanced[key + " empty pending"] = view.get("_queue") is Array and view._queue.is_empty()
		var log_rows: Array = view.get("command_log", [])
		log_checks.append({
			key + " literal log": _exact(log_rows, _commands(["I", "Q", "S"] + suffixes[index], true)),
			key + " raw log": _exact(log_rows, raw.command_log),
		})
		var result := owner.drain_events()
		var events: Array = result.get("events", [])
		drained[key + " drain"] = _drain_ok(result)
		drained[key + " raw events"] = _exact(events, raw.drain_events())
		drained[key + " command events"] = _event_order(events) == expected_events[index]
		drained[key + " tick/clock"] = _timeline(finished, raw)
		drained[key + " fleet fields"] = _fleet_parity(finished, raw)
		closed[key + " empty redrain"] = _empty_drain(owner)
		closed[key + " close"] = _closed(owner)
		_release_raw(raw)
	_check(1, restored)
	_check(2, queued)
	_check(3, advanced)
	for index in log_checks.size():
		_check(4 + index, log_checks[index])
	_check(7, drained)
	_check(8, closed)
	_end()

func _consumer(owner: OperationPrivateState, packet: Dictionary) -> void:
	_begin(3)
	_check(1, {"exact P restore": _restore(owner, packet)})
	var receiver: Array = []
	var first := owner.drain_events()
	var first_events: Array = first.get("events", [])
	receiver.append_array(first_events.duplicate(true))
	_check(2, {"first drain": _drain_ok(first), "payload": _exact(first_events, _view(packet).get("_events")),
		"first external copy": _exact(receiver, [] + first_events)})
	var drained_packet := _packet(owner)
	var expected_drained := packet.duplicate(true)
	var expected_empty: Array[Dictionary] = []
	expected_drained.view.sim._events = expected_empty
	_check(3, {"D differs from P only in events": _exact(drained_packet, expected_drained)})
	var restored_p := _restore(owner, packet)
	_check(4, {"exact P restore": restored_p, "receiver retained": _exact(receiver, [] + first_events)})
	var second := owner.drain_events()
	var second_events: Array = second.get("events", [])
	receiver.append_array(second_events.duplicate(true))
	_check(5, {"second drain": _drain_ok(second), "exact replayed payload": _exact(first_events, second_events)})
	var event_keys: Array = first_events[0].keys() if not first_events.is_empty() else []
	print("RECEIVER_EVENT_KEYS ", event_keys)
	var doubled: Array = [] + first_events + first_events
	_check(6, {"two copies": not first_events.is_empty() and _exact(receiver, doubled)})
	_check(7, {"exact D restore": _restore(owner, drained_packet), "drain empty": _empty_drain(owner),
		"receiver retained": _exact(receiver, doubled)})
	_check(8, {"closed": _closed(owner)})
	_end()

func _run() -> void:
	var world_link := root.get_node_or_null("WorldLink")
	var owner_script: Script = Private
	var sim_script: Script = SimScript
	if owner_script.resource_path != "res://core/battle/operation_private_state.gd" or sim_script.resource_path != "res://core/battle/battle_sim.gd" or Private._classes() != "" or world_link == null or world_link.get_script().resource_path != "res://scripts/world_link.gd":
		print("CANONICAL_RESOURCE_GUARD FAIL")
		quit(1)
		return
	var owner := _owner()
	var duplicate := _owner()
	var consumer := _owner()
	if owner == null or duplicate == null or consumer == null:
		print("OWNER_CREATE FAIL")
		quit(1)
		return
	var prefix_ok := true
	for index in TICK:
		prefix_ok = _exact(owner.advance(), {"ok": true}) and prefix_ok
	prefix_ok = _drain_ok(owner.drain_events()) and prefix_ok
	prefix_ok = _exact(owner.queue(_command("Q")), {"ok": true}) and prefix_ok
	prefix_ok = _exact(owner.queue(_command("S")), {"ok": true}) and prefix_ok
	prefix_ok = _exact(owner.issue(_command("I")), {"ok": true}) and prefix_ok
	var packet := _packet(owner)
	_correct(owner, packet, prefix_ok)
	_duplicate(duplicate, packet)
	_reordered(packet)
	_consumer(consumer, packet)
	print("PROBE_RESULT ", JSON.stringify({"ok": not failed, "checks": ids.size(), "ids": ids,
		"engine_path": OS.get_executable_path(), "engine_pid": OS.get_process_id()}))
	quit(int(failed))
