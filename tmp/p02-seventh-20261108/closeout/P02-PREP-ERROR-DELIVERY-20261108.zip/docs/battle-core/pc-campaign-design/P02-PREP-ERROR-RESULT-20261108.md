# P02 전투 준비 실패 표시와 최초 탈출 결과

2026-11-08 KST. 독립 구현 5-b는 지정 profile patch의 명시 실패 표시 및 최초 탈출을 한정 수용했다. 문서와 전달 ZIP은 독립 마감 대기다. 전체 P02/I01/I01b/A04~A06 **NOT_READY**, 외부 save schema **UNCLASSIFIED**.

`FleetBattle3D.gd`는 준비 실패 반환과 엔진 진단을 유지한다. 기존 전투 위에는 입력을 통과시키는 비모달 안내를 한 개만 표시하고 다음 정상 게시에서 지운다. 최초 실패에서 구형 출격 화면을 차단하고 단독 실행은 종료, 천하에서 들어온 경우는 결과 없이 WorldMap으로 돌아가는 버튼을 제공한다. ally와 foe 편성 형식 오류는 같은 문구로 표시한다.

- 사용자가 처음 Escape로 Windows 컴퓨터 제어를 중단해 실제 GUI 검사를 멈췄다. “다시 확인해줘” 요청 이후 독립 종료 및 천하 복귀를 각각 마우스와 Return으로 확인했다. 단독 두 입력 및 제품 버튼 03~08은 이전 공통 owner의 역사적 근거다. 현 동결 사본에서는 천하 복귀 두 입력과 네이티브 렌더를 다시 확인했다. WorldMap 활성, brief/outcome null, 표준/auto 및 settings 유지, trace 부재가 기록됐다.
- 버튼 03~08은 실제 마우스 좌표와 제품 버튼 콜백을 연결했다. 03/04 입력 주체와 03/05 대상 밖 입력은 원문에 남겼고, 마우스가 먼저 들어간 routed 키보드 실행은 키보드 성공 집계에서 제외했다. GUI 상태 비교는 sim ID, tick, org, G.state, selected, events 여섯 필드다. 별도 atomic의 clock, trace, 카메라, 캐시 등의 546개 단언을 GUI 클릭에 적용한 것은 아니다.
- 현재 공통 입력으로 다시 동결해 공통 8행/27단언, 사후 atomic 10행/546단언, 직접 profile·ally·foe 오류, 정상 재시도 및 BattleFlow/Organization UI를 확인했다. 최초 randomize 시작 트레이스는 이전과 현재 모두 strict 7/8이었다. 후속 고정 RNG의 별도 init_game 트레이스 한 행은 wall_time/mono_ms 외 전체가 일치했고 control/pos 변조를 거절했다.
- K4 WorldMap 자동 해결은 카드 준비에서 멈췄고 사전 WorldLink 둘은 시간 초과였다. K5는 실제 WorldMap 제품 버튼에 자동 viewport 입력을 전달했다. 양쪽 완료 14단언·취소 15단언, 동일 Brief seed 350157, 동일 완료 지문과 결산 한 번, 같은 resolver join 및 취소 결과 부재를 확인했다. 자동 viewport 입력은 Windows OS 입력과 별도다. K6 WorldLink 순차 네 실행은 전후 clean의 기존 서막 단일 실패(exit 1)와 returning 통과(exit 0)를 각각 재현했다. 전체 시도 K1~K6을 소모했다.
- 공통 owner 변화 C555…→AC59…를 같은 현재 입력으로 양쪽에 반영했다. P03 경로와 미귀속 산출물은 시점별 SHA 차이만 기록한다. 읽기 사이의 변경 부재나 변경 주체를 판정하지 않는다. ObjectDB/리소스 종료 진단의 원인은 확정하지 않았다.
- 구현과 5-b의 실제 모델은 권위 세션 turn_context의 gpt-6.1-sol과 gpt-6.1-terra다. 원문 경로와 행 SHA는 검증 기록을 따른다.

[전용 체크리스트](P02-PREP-ERROR-CHECKLIST-20261108.md) · [인계](SESSION-HANDOFF-P02-PREP-ERROR-20261108.md) · [검증 기록](../../../tmp/p02-seventh-20261108/K4-K5-EVIDENCE.md) · [독립 5-b](../../../tmp/p02-seventh-20261108/REVIEW-5B-INDEPENDENT.md) · [전달 ZIP](../../../tmp/p02-seventh-20261108/closeout/P02-PREP-ERROR-DELIVERY-20261108.zip)

적벽 operation 지원, FleetBattle3D·WorldMap 제품 operation 및 제품 replay 연결, owner restore 기능, Android와 성능은 별도 인수다.
