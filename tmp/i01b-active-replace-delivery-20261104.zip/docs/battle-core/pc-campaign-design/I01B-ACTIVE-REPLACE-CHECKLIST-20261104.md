# 제한 활성 owner 교체 — 체크리스트

2026-11-04 KST / **구성요소·기능5a·독립5b 제한 수용·6 기록 마감**. 전체 diff-check actual exit2 기존진단 유지. 전체 I01b/A04~A06 NOT_READY, 외부 schema UNCLASSIFIED.

[계획](../../../tmp/i01b-active-replace-20261102/PLAN.md) · [계획 독립 수용](../../../tmp/i01b-active-replace-20261102/REVIEW-PLAN-ACCEPT-20261102.md) · [결과](I01B-ACTIVE-REPLACE-RESULT-20261104.md) · [독립 리뷰](REVIEW-I01B-ACTIVE-REPLACE-20261104.md) · [현재 이관](SESSION-HANDOFF-I01B-ACTIVE-REPLACE-20261104.md).

- [x] 필수 지침·실제 소비자/미완료 계약 확인, branch/HEAD/index와 기존3879 SHA 동결.
- [x] 중복 facade 없이 기존 owner에 최소 메서드를 더하는1~3 작성.
- [x] 독립 R1~R4 보완: readonly I/O 사실·busy/lifecycle·typed context·사건/실제효과 경계.
- [x] 다른 모델의 보완 계획 독립 수용.
- [x] helper42행 추가와 신규 검사 구현. 기존 API/P2b/core/데이터/host/기존 검사 불변.
- [x] attempt1 ParseError exit1 원문과 입력 보존, 사례 미실행으로 구분.
- [x] attempt2 actual exit0, 정상20/20099체크/명명8·실제거부9, 신규로그 오류/누수0.
- [x] POC 실제 공격·services 기억/보급진행/완료재고와 public suffix·identity/bindings/alias·실패 원자성 검증.
- [x] P2c OUT-only 회귀70/11553/45·core/data 모두 actual exit0. 역치환 SHA exact.
- [x] 전체 diff-check actual exit2의 기존 상위P2c행 CRLF 원문/SHA 보존. 신규 코드 공백0. 전체 PASS로 표시하지 않음.
- [x] 구현 비참여 gpt-6-astra 최종5b 제한 수용·83항/입력42/3879/source35/격리77 직접 감사.
- [x] 최종 결과·독립 리뷰·상위 추가1행·이관 기록과 문서 이후 보존 감사/SHA manifest/압축 인계 마감.

새 단계 runner는2/K6, 이전 P2c는5/K6로 별도 기록한다. 검사/allowlist/skip을 완화하지 않았고 이미 통과한 무관 검사를 반복하지 않았다. HTML 기능/다운로드 QA는 중지이며 이번에도 HTML을 수정하지 않았다.

실제 host/headless/replay 공통 연결·운영 Cn/global cursor·외부 저장/스키마·제품 공간·전체 캠페인/모든 ST01~18·화면/Android·성능/사람플레이는 미완료다. 커밋·푸시·병합·브랜치 전환·새worktree·editor import 없음.
