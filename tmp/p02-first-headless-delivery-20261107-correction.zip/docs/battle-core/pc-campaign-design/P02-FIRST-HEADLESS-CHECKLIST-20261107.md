# P02 첫 실제 headless 연결 — 전용 체크리스트

2026-11-07 KST. 이번 조각의 비-Astra 독립 5b와 마감 재심사는 수용 보류 중이다. 전체 P02/I01/I01b/A04~A06 NOT_READY, 외부 save schema UNCLASSIFIED. [결과](P02-FIRST-HEADLESS-RESULT-20261107.md)와 [인계](SESSION-HANDOFF-P02-FIRST-HEADLESS-20261107.md)를 따른다.

- [x] 0 지침·원본 branch/HEAD/index·dirty/untracked3960 SHA·기존 소유 경계 동결. source35/격리77과 과거3879/3660 분모 구분.
- [x] 1~3 실제 FleetBattle3D/AutoResolver/autoresolve/replay 책임·실패 반례 조사. 공통 factory와 host 고유 표시/스레드 책임 분리. v1 반려 R1~R4→v2 독립 수용.
- [x] 4 실제 CLI --operation-input opt-in·strict 입력·한 번 정규화·private owner·public read·no-clobber 결과 연결. legacy 기본 경로와 기존 본문 바이트 보존.
- [x] 5a attempt1 실패 보존→독립 정책 보완계획 수용→attempt2 oracle 표현 실패 보존→attempt3/K6 actual exit0. 정상matrix8/13417체크·P9·T2·APInegative32.
- [x] 5a 실제 CLI14거부+2성공+legacy1쌍(18프로세스) 및 private/core 회귀2. 모든 정본 로그 SCRIPT ERROR/ERROR0, actual exit/SHA/OUT-only 역치환 구분.
- [ ] 5b [비-Astra 독립 구현 검토](../../../tmp/p02-first-integration-20261105/REVIEW-5B-NON-ASTRA-20261107.md)에서 차단 반례 미발견. gpt-6.1-sol 구현과 gpt-6.1-terra 검토는 별도 실제 세션이다. 과거 gpt-6-astra 심사는 이력으로 보존한다. 문서·마감 반려 후 정정본 재심사 대기.
- [ ] 6 결과·체크리스트·인계와 상위 P02 행을 정정하고 감사·manifest·ZIP 검증을 동결했다. 독립 마감 재심사 대기.

비-Astra 독립 마감 판정은 보류 중이다. [최종 감사](../../../tmp/p02-first-integration-20261105/closeout-correction/audit.json)와 [압축 검증](../../../tmp/p02-first-integration-20261105/closeout-correction/archive-verification.json)의 분모가 이번 최종 시점 정본이다. pre-review235는 이후 문서·심사·압축을 포함하지 않은 별도 시점이다.

- [ ] 전체 P02: FleetBattle3D UI/clock/binding, worker 소유권/완료 공개, replay 및 소비자 공동 I01/K01~08 인수.
- [ ] 기존 --no-chain/--no-m9/--wind의 conflicting/unknown 진단 분류 편차 후속. 현재는 fail-closed unknown_option 제한 수용이며 실제 CLI14에 추가하지 않음.
- [ ] 이번 services CLI에서 supply 완료 사건 E2E. 모듈/상태 비교·기존 P2c 보급 회귀와 구분.
- [ ] write/flush/verify 디스크 fault injection·OS 동시 writer 원자성. 현재 지원/실증 범위 아님.
- [ ] P03~P09·전체 저장/재개·외부 schema/호환·운영 Cn/global cursor·제품 공간·UI/Android/성능/사람플레이.
- [ ] 기존 ObjectDB/resources/TRACE 품질 진단 및 전체 diff-check의 기존 P2c 33행 해소. 이번 성과로 자동 완료하지 않음.

기존 ZIP2·실패 attempt1/2·정본 attempt3와 과거 오염 cache 이력을 보존한다. HTML/browser/localStorage/editor import·새 worktree/branch전환·커밋/푸시/병합은 범위 밖이다. 사용량 제한이면 즉시 보고하고 반복하지 않는다.
