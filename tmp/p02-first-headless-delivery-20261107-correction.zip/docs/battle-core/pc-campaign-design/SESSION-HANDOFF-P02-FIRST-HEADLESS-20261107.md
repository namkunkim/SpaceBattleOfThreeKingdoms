# P02 첫 실제 headless 연결 — 최신 인계

2026-11-07 KST. [결과](P02-FIRST-HEADLESS-RESULT-20261107.md)·[체크리스트](P02-FIRST-HEADLESS-CHECKLIST-20261107.md)를 먼저 읽는다. 이번 조각은 실제 CLI opt-in 연결을 구현·검사했으며 전체 P02/I01/I01b/A04~A06 NOT_READY, 외부 save schema UNCLASSIFIED다. [비-Astra 독립 5b](../../../tmp/p02-first-integration-20261105/REVIEW-5B-NON-ASTRA-20261107.md)는 구현 범위에서 차단 반례를 발견하지 못했고, 문서·마감 정정본 재심사를 기다린다.

원본 `C:/WorkSpace/SpaceBattleOfThreeKingdoms`, branch `codex/feature-i01b-not_remove`, HEAD `fb660cea69207fd332e26128643007694910a253`, index 빈 상태를 유지했다. 재개 시 실제 상태·워크플로우-플레이북/CLAUDE·부모/하위 AGENTS를 다시 확인한다. 기존 tracked/untracked 변경을 폐기하거나 새 worktree/branch·커밋/푸시/병합을 만들지 않는다. HTML 기능/다운로드 QA·브라우저/localStorage 변경 중지는 계속된다. 사용량 제한은 즉시 보고하고 반복하지 않는다.

## 실제 연결과 호환 경계

`operation_runtime_adapter.gd`는 명시 runtime-ready 입력의 검증·한 번 JSON 정수 정규화·원자적 fresh private 구축을 담당하는 static factory다. owner public read2개와 기존 queue/advance/drain/close를 실제 `tests/autoresolve.gd --operation-input <JSON> --out <새경로>`가 소비한다. opt-in 기본값은 꺼짐이다. 입력/지원밖/출력 실패는 명시 exit1이며 legacy fallback·모듈/증원 임의 제거가 없다. no-clobber 출력과 close-before-write 계약은 결과 문서를 따른다.

초기 controls []와 명시 delegate 배열·정확 Variant/키/순서/typed identity 계약을 완화하지 않았다. private 추가 read 때문에 code SHA가 바뀌었으며 과거 packet 호환 보증은 없다. I01a synthetic geometry 설정을 runtime 입력으로 승격하지 않았고 source→effective 변환·전체 K02/hash/ID/cursor 계약은 미완료다. stock POC 전체/실제 적벽/다른 활성 모듈을 지원한다고 가정하지 않는다.

정책은 public projection만 본다. none 즉시 반환, attack5는 copied 정책뷰의 confirmed/estimated contact에 현재 Detection.foes 의미로 dead=false만 보완하고 lost를 제외한다. 기존 legacy 정책/play/play_rc/통계 본문은 추가 hunk 역제거 시 사전 바이트와 같다. 실제 UI host의 G/vm/clock/선택/카메라/trace 및 worker thread에 동기 owner를 공유하는 통합은 구현하지 않았다.

## 정본 실행과 보존

증거 루트 `tmp/p02-first-integration-20261105/`. 최초 계획 v2와 attempt1 반례 보완계획 모두 독립 수용을 거쳤다. attempt1 실제 exit1/dead SCRIPT ERROR8112+assertion1, attempt2 실제 exit1/script0/typed aggregate oracle assertion2를 실패로 보존한다. 정본은 **attempt3/K6**, 이전 P2c5/활성교체2와 별도다.

attempt3 API actual exit0·정상matrix8/13417체크·정책P9·timeoutT2·API거부32. 실제CLI거부14 각exit1·성공2 exit0·legacy전후1쌍 exact JSON 바이트 동일, API32+CLI14=명명46. CLI는17논리항목/18프로세스, API runner1/회귀2와 구분한다. private70/11553/45·core actual exit0, 정본 합계21프로세스 SCRIPT ERROR/ERROR0. matrix natural7/timeout1과 POC조기종료2개의 중간체크포인트 부재는 원문 관측이다. tick×100으로 실제 clock/end를 재구성하지 않는다.

실제CLI services는 contact/salvo/ship_lost/종료 사건을 확인했지만 supply 완료 사건 E2E는 미검증이다. --no-chain/--no-m9/--wind 혼합은 conflicting_option 대신 unknown_option으로 명시 거부되는 분류 편차가 관측됐다. 이3개를 실제CLI14에 포함하지 않았다. disk write/flush/verify fault injection 및 OS writer 경합 원자성은 지원/실증하지 않았다.

최종 코드 SHA는 다음과 같다.

| 경로 | SHA256 |
|---|---|
| core/battle/operation_runtime_adapter.gd | `0c0cad3e6e4e15887dcd75f9d5b57dbbe2690bfdcafd1caac163909b5421173a` |
| core/battle/operation_private_state.gd | `dd47ceebaad2c5139bd8012deb841815cf0707c2231de202a00756913c0fa427` |
| tests/autoresolve.gd | `a6c3ee903e2365569a31aa0194acb426d87c5856a74a9c7dcaaedeaeea18b5b8` |
| tests/p02_headless_adapter.gd | `e44e964ed76f4d7d2edab8ebffa238672c70717670b6d82738120c72dfea9583` |

정본 cache `0eb214ebcc65cd2ca7b9d98dc83f61a9c170ca75b1b23acf4c3c58fdfb550ab1` 불변, editor import 없음. source snapshot은 .txt로 보관했고 실제 resource_path guard를 통과했다. 기존 snapshot/오염 cache 이력이나 P2c 무효 attempt를 지우지 않았다.

baseline3960·source35·격리77과 HTML/과거ZIP2·기존검사 보존은 [최종 감사](../../../tmp/p02-first-integration-20261105/closeout-correction/audit.json)를 따른다. clean tracked autoresolve와 상위 문서의 사전 원문/SHA·허용 diff/역제거 증거도 있다. 과거3879/3660이나 심사전manifest235를 현재 최종 분모와 혼합하지 않는다. 정정 전 전체 diff-check는 P2c 33행과 P02 35행을 진단했다. P02 35행만 정정했고 기존 P2c 33행은 전체 게이트 미통과로 남아 있다. 이번 data_rules 미실행이고 기존 ObjectDB/resources/TRACE 진단은 남는다.

새 [P02 압축](../../../tmp/p02-first-headless-delivery-20261107-correction.zip)의 목록·CRC·SHA는 [archive-verification.json](../../../tmp/p02-first-integration-20261105/closeout-correction/archive-verification.json), payload는 [record-manifest.json](../../../tmp/p02-first-integration-20261105/closeout-correction/manifest.json)을 따른다. 과거 P2c ZIP SHA `99a4a1adca1bdc3bf7e56baa9112c1625ab6c6371bfaafa0482b3471903a2971`, 활성교체 ZIP SHA `87a090a8d891391473fd9dfa9627dcd4430af234359e06d0b78e9e7b5f005eae`는 유지한다. 새 문서나 코드를 과거 ZIP에 소급 포함하지 않는다. 최종 closeout은 ZIP 작성 뒤의 외부 독립 판정이며 압축 당시 포함 목록과 구분한다.

## 다음 작은 조각

P02 공통 factory를 실제 UI host/worker/replay에 적용할 입력/소유권/게시/실패 계약을 각각 작은1~3로 독립 계획 심사한다. UI는 sim만 교체하지 말고 clock/G/vm/선택/trace candidate commit을, worker는 worker 단독 구축·소비·close와 join후 완료 DTO 공개를 계획해야 한다. 기존 legacy와 실패 시 현재 host/부수효과 보존을 공동 검증한다. 원 P02/I01/K01~08 인수조건을 유지하며 P03~P09·전체 저장/재개·운영 Cn/global cursor·제품 공간·화면/Android/성능 완료를 자동 선언하지 않는다.
